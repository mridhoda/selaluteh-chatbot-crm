# Encyclopedias API

## Status

This file appears to be a legacy or cross-project API spec name.

For the current backend direction:

```txt
SelaluTeh Chatbot CRM
+ Telegram-first Marketplace MVP
```

there is no required `encyclopedias` API in the MVP scope.

## Recommendation

Do not implement encyclopedia generation inside this backend unless it becomes a confirmed product requirement.

If this file exists because of an older Luma Learn/encyclopedia-generator project, keep this doc as a placeholder only and avoid mixing it with marketplace APIs.

## Reserved Future Route

If ever needed, use a separate bounded context:

```txt
/api/v1/encyclopedias
```

Do not mix it with:

```txt
products
carts
orders
payments
chatbot CRM
```

## Current Action

For this project, mark as:

```txt
Not in MVP scope.
```
