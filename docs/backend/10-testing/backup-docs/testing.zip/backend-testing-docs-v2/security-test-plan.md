# Security Test Plan

## Goal

Validate security-critical behavior before staging/production release.

## Auth/Authz

- [ ] Unauthenticated user cannot access protected API.
- [ ] Agent role cannot access owner-only APIs.
- [ ] Cross-workspace chat read is blocked.
- [ ] Cross-workspace order update is blocked.
- [ ] Cross-workspace file read is blocked if protected media endpoint is used.

## Webhooks

- [ ] Telegram webhook validates platform token/secret strategy.
- [ ] Meta verification works.
- [ ] Payment webhook rejects invalid signature.
- [ ] Duplicate webhook is idempotent.
- [ ] Large malformed payload does not crash server.

## Secrets

- [ ] `.env` not committed.
- [ ] Service role key never exposed to frontend.
- [ ] Platform tokens not returned in public API responses.
- [ ] Logs do not contain full tokens/API keys.

## AI Safety

- [ ] Prompt injection cannot trigger unsafe action.
- [ ] AI cannot mark payment/order as paid.
- [ ] AI cannot expose system prompt or secrets.
- [ ] AI cannot access another user's order.

## Abuse/Rate Limit

- [ ] Login brute force is limited.
- [ ] Webhook endpoint has payload size limit.
- [ ] Public file routes have reasonable access policy.
- [ ] Repeated callback query does not spam payment/order creation.

## Payment

- [ ] Amount cannot be tampered by client.
- [ ] Payment provider amount equals server order amount.
- [ ] Status downgrade rejected.
