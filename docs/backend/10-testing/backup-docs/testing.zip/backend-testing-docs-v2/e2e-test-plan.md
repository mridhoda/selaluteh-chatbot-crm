# E2E Test Plan

## Goal

E2E tests validate full customer/admin journeys across API, database, webhook simulation, and UI where possible.

## MVP Critical E2E Journeys

### 1. Owner Onboarding

```txt
Register owner
-> verify OTP
-> login
-> open dashboard
-> create Telegram platform
-> create default AI agent
```

Acceptance:

- Workspace exists.
- Owner user exists.
- Dashboard loads.
- Platform and agent are workspace-scoped.

### 2. Telegram Chatbot CRM Journey

```txt
Telegram /start webhook
-> contact created
-> chat created
-> message saved
-> AI reply saved
-> reply sent to Telegram mock
```

Acceptance:

- No duplicate message on retry.
- Message appears in inbox.
- AI stops when human takeover is active.

### 3. Telegram Marketplace Happy Path

```txt
User opens Telegram bot
-> taps Browse Products
-> selects product
-> adds item to cart
-> views cart
-> checkout
-> receives payment link
-> payment webhook paid
-> receives paid notification
-> admin sees paid order
```

Acceptance:

- Cart and order are deterministic.
- Order has order_items.
- Payment has payment_events.
- Telegram notification is sent exactly once.

### 4. Human Takeover Journey

```txt
User asks complex question
-> AI escalates
-> admin takes over chat
-> user sends new message
-> AI does not reply
-> human sends reply
```

Acceptance:

- `takeover_by` is set.
- New user message does not trigger AI reply.
- Human message is sent to provider.

### 5. Complaint Journey

```txt
User reports issue
-> AI/action creates complaint draft or admin creates complaint
-> admin updates complaint status
-> audit trail is kept
```

## Tooling Options

- API/webhook E2E: Jest/Vitest + Supertest.
- UI E2E: Playwright.
- Staging manual E2E: real Telegram bot + payment sandbox.

## Production Smoke Tests

Run only safe tests:

- Login.
- Load dashboard.
- Send Telegram test message from internal account.
- Create test product hidden from public.
- Create sandbox payment only in staging, not production.
