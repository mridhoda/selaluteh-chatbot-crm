# Backend Documentation Index

Project:

```txt
SelaluTeh Chatbot CRM — Telegram Marketplace MVP
```

This documentation set is the source of truth for the backend direction, architecture, product scope, API, database, security, testing, operations, and AI coding-agent workflow.

## 1. Project Summary

This backend started as an **AI Chatbot CRM** with:

- Telegram webhook
- WhatsApp/Instagram webhook
- AI agents
- Inbox/chat history
- Human takeover
- Contacts
- Legacy orders and complaints
- MongoDB/Mongoose runtime
- React/Vite admin dashboard
- Express backend

The new target is:

```txt
Telegram-first single-merchant marketplace MVP
```

Core MVP flow:

```txt
Telegram user
→ browse products
→ add to cart
→ checkout
→ receive payment link
→ sandbox payment webhook
→ paid order notification
→ admin sees order/payment status
```

## 2. Main Rule

Do not rebuild from scratch.

Continue the existing Chatbot CRM and add commerce features safely:

```txt
stabilize existing CRM
→ secure routes
→ add webhook idempotency
→ add product catalog
→ add cart
→ add checkout
→ add payment sandbox
→ add Telegram commerce flow
→ harden MVP
```

## 3. Folder Map

| Folder | Purpose | Read When |
|---|---|---|
| `0000-business/` | Business strategy, BRD, business model, pricing, GTM, revenue, risks | Product/business direction changes |
| `00-overview/` | High-level project summary, scope, goals, assumptions, target state | Starting context |
| `000-research/` | Market/technical research, competitor notes, benchmark docs | Researching decisions |
| `01-product/` | Product requirements, personas, features, MVP scope, user stories | Product behavior changes |
| `02-flows/` | Process flows: auth, admin, checkout, Telegram, payment, webhook, AI, takeover | Before implementing feature flows |
| `03-business-rules/` | Domain/business rules: permissions, status, validation, payment, order, AI rules | Before writing business logic |
| `04-tech-spec/` | Backend architecture, stack, folder structure, coding rules, storage, jobs, observability | Before backend architecture/code changes |
| `05-api-spec/` | Endpoint contracts, request/response shape, errors, rate limits | Before creating/changing APIs |
| `06-data/` | Database schema, migration plan, RLS, indexes, relationships, storage model | Before schema/migration/entity changes |
| `07-uiux/` | Backend-driven UI requirements: pages, buttons, forms, tables, states | Before building admin dashboard/backend-supported UI |
| `08-security/` | Security policy, threat model, authz, API security, webhook/payment security | Before protected routes, payment, deploy |
| `09-ai-context/` | AI coding-agent context: boundaries, do-not-break, task context, response format | Before giving tasks to AI agents |
| `10-testing/` | Test strategy, unit/integration/e2e, QA, regression, payment/webhook tests | Before closing tasks |
| `11-sprint/` | Roadmap, sprint plan, backlog, DoD, task breakdown, progress/status | Before deciding next task |
| `12-ops/` | Deployment, rollback, backup/restore, monitoring, incidents, troubleshooting | Before deployment/production operation |
| `brief/` | Short context packs for fast onboarding and AI handoff | Before quick AI task briefing |
| `chatgpt-context/` | Master AI context packs/prompts for ChatGPT/Claude/Cursor/Windsurf | Before long AI-assisted implementation sessions |
| `index.md` | This map of all docs | Start here |
| `READING-ORDER.md` | Prompt-style reading instructions before coding | Give this to AI agent before any task |

## 4. Recommended Starting Points

### If you are a human developer

Read:

```txt
index.md
READING-ORDER.md
00-overview/project-summary.md
brief/project-brief.md
11-sprint/implementation-status.md
11-sprint/current-sprint.md
```

### If you are an AI coding agent

Start with:

```txt
READING-ORDER.md
brief/quick-prompt-for-ai-agent.md
09-ai-context/prompt-context.md
09-ai-context/do-not-break.md
11-sprint/current-sprint.md
11-sprint/task-breakdown.md
```

### If you are implementing backend architecture

Read:

```txt
04-tech-spec/architecture.md
04-tech-spec/folder-structure.md
04-tech-spec/tech-stack.md
04-tech-spec/coding-rules.md
04-tech-spec/database-access.md
04-tech-spec/background-jobs.md
04-tech-spec/storage-strategy.md
```

### If you are implementing APIs

Read:

```txt
05-api-spec/overview.md
05-api-spec/error-format.md
05-api-spec/api-versioning.md
05-api-spec/rate-limits.md
05-api-spec/auth-api.md
05-api-spec/products-api.md
05-api-spec/carts-api.md
05-api-spec/checkout-api.md
05-api-spec/orders-api.md
05-api-spec/payments-api.md
05-api-spec/webhooks-api.md
```

### If you are implementing database/migration

Read:

```txt
06-data/README.md
06-data/database-schema.md
06-data/entities.md
06-data/relationships.md
06-data/erd.md
06-data/data-flow.md
06-data/indexes.md
06-data/rls-policies.md
06-data/migration-plan.md
06-data/storage-model.md
```

Also check migration SQL/docs if present:

```txt
06-data/migrations/README.md
06-data/migrations/sql/*
06-data/migrations/notes/*
06-data/migrations/checklists/*
```

### If you are implementing Telegram commerce

Read:

```txt
02-flows/telegram-commerce-flow.md
02-flows/checkout-flow.md
02-flows/payment-flow.md
03-business-rules/telegram-commerce-rules.md
03-business-rules/cart-checkout-rules.md
05-api-spec/telegram-commerce-api.md
07-uiux/telegram-bot-ux.md
09-ai-context/telegram-bot-context.md
```

### If you are implementing payment

Read:

```txt
02-flows/payment-flow.md
03-business-rules/payment-rules.md
05-api-spec/payments-api.md
05-api-spec/webhooks-api.md
08-security/payment-security.md
10-testing/payment-test-plan.md
12-ops/payment-ops.md
```

### If you are implementing AI assistant behavior

Read:

```txt
04-tech-spec/ai-pipeline.md
09-ai-context/ai-pipeline-rules.md
09-ai-context/commerce-agent-guardrails.md
09-ai-context/ai-action-contract.md
09-ai-context/tool-calling-contract.md
08-security/ai-prompt-security.md
10-testing/ai-agent-evaluation.md
```

### If you are implementing admin UI/dashboard

Read:

```txt
07-uiux/backend-ui-contract.md
07-uiux/pages-backend-requirements.md
07-uiux/admin-actions-matrix.md
07-uiux/forms-and-fields.md
07-uiux/data-table-actions.md
07-uiux/workflow-buttons.md
05-api-spec/*
```

### If you are preparing deployment/production

Read:

```txt
12-ops/production-readiness.md
12-ops/deployment-runbook.md
12-ops/release-runbook.md
12-ops/rollback-runbook.md
12-ops/backup-restore-runbook.md
12-ops/monitoring-alerting.md
08-security/security-checklist.md
10-testing/smoke-test-checklist.md
```

## 5. Current MVP Priority

Default current priority:

```txt
Sprint 0 — Stabilization
```

Before adding marketplace/payment:

- secure orders routes
- secure complaints routes
- protect/remove diagnostic routes
- preserve existing CRM behavior
- add webhook idempotency
- keep workspace isolation

## 6. Do Not Break

Any task must preserve:

- login/register/verify
- dashboard
- platforms
- agents
- inbox/chats
- message history
- Telegram webhook
- AI reply pipeline
- human takeover
- contacts
- legacy orders/complaints compatibility
- local file serving/storage
- workspace isolation

## 7. Deprecated or Irrelevant References

Do not use old docs from unrelated projects as source of truth.

Examples of irrelevant old docs:

```txt
encyclopedias-api.md
assets-api.md
exports-api.md
image-generation docs
cliproxy docs
```

Only keep them if explicitly marked as reserved/legacy and intentionally needed.

For this backend, the core API docs should focus on:

```txt
auth
users
platforms
integrations
agents
chats
contacts
products
carts
checkout
orders
payments
webhooks
telegram commerce
AI actions
complaints
files
analytics
settings
jobs
```

## 8. Documentation Maintenance Rule

Whenever code changes behavior, update docs in the matching folder.

Examples:

- new API endpoint → update `05-api-spec`
- new table/model → update `06-data`
- new business logic → update `03-business-rules`
- new flow → update `02-flows`
- new security rule → update `08-security`
- new sprint progress → update `11-sprint/progress-log.md`
- production procedure → update `12-ops`
