# Telegram Commerce Flow

Dokumen ini menjelaskan flow belanja user dari Telegram untuk Marketplace MVP.

## Goal

Customer dapat melakukan pembelian melalui bot Telegram:

```txt
/start -> browse products -> add to cart -> checkout -> payment link -> payment success notification
```

## Entry Points

| Entry Point | Behavior |
|---|---|
| `/start` | Show welcome message + main menu |
| `Browse Products` button | Show categories/products |
| `Cart` button | Show current cart |
| `Order Status` button | Ask/select recent order |
| Free text | AI assistant may help, but deterministic buttons should remain available |

## Main Menu

Recommended Telegram menu:

```txt
Halo! Mau ngapain hari ini?

[Browse Products]
[My Cart]
[Order Status]
[Talk to Admin]
```

## Happy Path

```mermaid
sequenceDiagram
  participant U as Telegram User
  participant TG as Telegram
  participant API as Backend
  participant DB as Database
  participant PG as Payment Gateway

  U->>TG: /start
  TG->>API: webhook update
  API->>DB: upsert contact/chat
  API-->>TG: send main menu
  U->>TG: Browse Products
  TG->>API: callback_query
  API->>DB: query active products
  API-->>TG: send product list
  U->>TG: Select product
  TG->>API: callback_query
  API->>DB: load product detail
  API-->>TG: send detail + add button
  U->>TG: Add to cart
  TG->>API: callback_query
  API->>DB: create/update cart_item
  API-->>TG: cart summary
  U->>TG: Checkout
  TG->>API: callback_query
  API->>DB: create checkout/order/order_items
  API->>PG: create payment transaction
  API->>DB: save payment
  API-->>TG: send payment link
```

## Callback Action Naming

Use stable callback action patterns:

```txt
menu:home
catalog:list
catalog:category:<category_id>
product:view:<product_id>
variant:select:<variant_id>
cart:add:<product_id>:<variant_id>
cart:view
cart:remove:<cart_item_id>
checkout:start
checkout:confirm:<checkout_id>
order:status:<order_id>
handoff:admin
```

Avoid putting sensitive data in callback data.

## State Storage

The user journey should be stored in backend state, not only Telegram callback data.

Recommended places:

```txt
contacts -> identity
chats -> conversation and state
carts -> active cart
cart_items -> selected items
checkouts -> checkout attempt
orders -> committed order
payments -> payment record
```

## AI Interaction

AI can help when user types free text:

```txt
User: ada kopi yang manis?
AI: Aku rekomendasikan Salty Caramel. Mau lihat detailnya?
Button: View Product
```

But actions such as add-to-cart and checkout should go through backend validation.

## Human Handoff

If user clicks `Talk to Admin`:

```txt
Set chats.is_escalated = true
Optionally set takeover_by when admin accepts
AI stops when takeover_by exists
```

## Telegram UX Rules

- Prefer buttons for commerce-critical actions.
- Always confirm checkout summary before creating payment link.
- Do not ask payment details inside chat.
- Send payment link from trusted backend only.
- After payment success, notify user automatically.

## Failure Handling

| Failure | Bot Response |
|---|---|
| Product not found | Product sudah tidak tersedia, pilih produk lain |
| Cart empty | Keranjang kamu masih kosong |
| Checkout expired | Checkout sudah expired, buat ulang ya |
| Payment pending | Pembayaran belum terkonfirmasi |
| Payment failed | Pembayaran gagal/expired, coba checkout ulang |
| Backend error | Maaf, sistem sedang bermasalah. Aku hubungkan ke admin |
