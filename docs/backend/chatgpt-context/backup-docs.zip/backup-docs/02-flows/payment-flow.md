# Payment Flow

Dokumen ini menjelaskan flow payment gateway sandbox untuk Telegram Marketplace MVP.

## Scope

MVP payment flow menggunakan payment link dari provider seperti Midtrans/Xendit. User membayar di halaman provider, bukan memasukkan data pembayaran di Telegram.

## Payment Happy Path

```mermaid
sequenceDiagram
  participant U as Telegram User
  participant API as Backend
  participant PG as Payment Gateway
  participant DB as Database
  participant Bot as Telegram Bot

  U->>API: Confirm checkout
  API->>DB: Create order pending_payment
  API->>DB: Create payment pending
  API->>PG: Create payment transaction/link
  PG-->>API: payment_link_url + provider_reference
  API->>DB: Save provider data
  API->>Bot: Send payment link
  U->>PG: Pay sandbox transaction
  PG->>API: Webhook payment status
  API->>API: Verify signature
  API->>DB: Save payment_event
  API->>DB: Update payment status paid
  API->>DB: Update order status paid
  API->>Bot: Notify payment success
```

## Payment Status

| Status | Meaning |
|---|---|
| pending | Payment link created, not paid yet |
| paid | Provider confirms settlement/success |
| failed | Provider reports failed |
| expired | Payment expired |
| cancelled | User/admin/provider cancelled |
| refunded | Refund completed |
| partially_refunded | Partial refund completed |

## Order Status Coupling

| Payment Status | Order Status Impact |
|---|---|
| pending | order remains `pending_payment` |
| paid | order becomes `paid` |
| expired | order becomes `cancelled` or `payment_expired` depending enum |
| failed | order can remain pending or become payment_failed |
| refunded | order becomes refunded/cancelled depending policy |

## Provider Webhook Flow

```txt
Payment provider sends webhook
-> backend verifies signature
-> backend checks idempotency by provider_event_id/provider_reference
-> backend stores payment_event raw payload
-> backend maps provider status to internal status
-> backend updates payment row
-> backend updates order row if valid transition
-> backend notifies Telegram user if status changed
```

## Signature Verification

Payment webhook must never update payment/order before signature verification.

Recommended steps:

```txt
Read raw request body
Compute/verify provider signature
Reject if invalid
Process idempotently
```

## Idempotency

Store each payment webhook in `payment_events`:

```txt
provider
provider_event_id
provider_reference
payment_id
order_id
raw_payload
processed_at
```

If duplicate event arrives:

```txt
Return 200 OK but do not reprocess side effects.
```

## Payment Link Telegram Message

Example:

```txt
Pesanan kamu sudah dibuat ✅
Total: Rp75.000

Silakan bayar melalui link berikut:
<provider_payment_link>

Setelah pembayaran berhasil, aku akan otomatis kabari kamu di sini.
```

## Manual Payment Compatibility

Current system may still support manual QRIS/payment proof. Keep it as fallback:

```txt
payment_provider = manual
payment status updated by admin after verification
payment_proof_file_id optional
```

But for MVP automation, use gateway sandbox as primary path.

## Reconciliation Flow

If webhook fails or is delayed:

```txt
Admin opens payment detail
-> backend queries provider status manually
-> updates payment/order if provider confirms status
-> stores reconciliation event
```

## Failure Cases

| Case | Behavior |
|---|---|
| Invalid signature | Reject and log security event |
| Unknown order reference | Store event as unmatched, alert admin |
| Duplicate webhook | Return 200, no duplicate side effects |
| Paid event after cancelled | Follow valid transition policy; require admin review |
| Provider timeout on create link | Mark payment failed/provider_error, allow retry |
