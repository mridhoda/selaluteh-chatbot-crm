# Checkout Flow

Dokumen ini menjelaskan flow cart, checkout, order creation, dan payment link generation.

## Purpose

Checkout adalah batas antara cart sementara dan order resmi. Cart boleh berubah, sedangkan order harus immutable secara finansial kecuali melalui status/refund/cancel flow.

## Main Entities

```txt
carts
cart_items
checkouts
orders
order_items
payments
payment_events
```

## Cart Flow

```mermaid
flowchart TD
  A[User adds item] --> B{Active cart exists?}
  B -->|No| C[Create cart]
  B -->|Yes| D[Use active cart]
  C --> E[Validate product/variant]
  D --> E
  E --> F{Product sellable?}
  F -->|No| X[Reject add]
  F -->|Yes| G[Insert or update cart_item]
  G --> H[Return cart summary]
```

## Checkout Start Flow

```txt
User clicks Checkout
-> backend loads active cart
-> validates cart is not empty
-> validates products are active
-> validates variants/stock
-> recalculates totals from database
-> creates checkout row
-> sends checkout summary to Telegram
```

## Checkout Confirmation

```txt
User confirms checkout
-> backend verifies checkout is still pending and not expired
-> creates order
-> copies cart items into order_items
-> marks checkout as converted
-> marks cart as checked_out
-> creates payment transaction
-> sends payment link
```

## Checkout State Machine

| State | Meaning |
|---|---|
| draft | Created but not confirmed |
| pending_confirmation | Waiting for user confirmation |
| converted | Order created |
| expired | User did not confirm in time |
| cancelled | User/admin cancelled |

## Order Creation Rules

When creating order from checkout:

- Use backend-calculated totals only.
- Create `order_items` with product snapshots.
- Do not trust price/quantity from Telegram callback payload.
- Store `contact_id`, `chat_id`, `workspace_id`, and `source='telegram'`.
- Initial order status should be `pending_payment`.

## Pricing Calculation

For MVP:

```txt
subtotal = sum(cart_item.quantity * current_unit_price)
discount_total = 0 initially
tax_total = 0 initially
shipping_total = 0 initially or manual flat value
grand_total = subtotal - discount_total + tax_total + shipping_total
```

Store calculated totals on order.

## Payment Link Creation

After order is created:

```txt
payment = create payment row status=pending
provider response = create transaction/payment link
save provider_reference + payment_link_url
send payment link to user
```

If provider creation fails:

```txt
order remains pending_payment
payment row status=failed or provider_error
user sees retry message
admin can inspect logs
```

## Cart Expiration

Recommended MVP rule:

```txt
Cart expires after 24 hours of inactivity.
Checkout expires after 15-30 minutes.
```

## Edge Cases

| Case | Behavior |
|---|---|
| User checkout twice | Reuse pending checkout or block duplicate |
| Payment created twice | Check idempotency by order_id + provider |
| Cart item price changed | Show updated summary before confirmation |
| Empty cart | Return cart empty message |
| Checkout expired | Ask user to create new checkout |
| User adds item after checkout | Create/use new active cart |
