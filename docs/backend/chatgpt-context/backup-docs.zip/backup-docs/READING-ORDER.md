# Reading Order Prompt Before Coding

Use this document as a **mandatory prompt** for any AI coding agent before it executes a backend coding task.

Project:

```txt
SelaluTeh Chatbot CRM — Telegram Marketplace MVP
```

## Copy-Paste Prompt for AI Coding Agent

```txt
You are working inside the SelaluTeh Chatbot CRM backend project.

Before you edit, generate, refactor, delete, migrate, or execute any coding task, you MUST first understand the documentation context.

This project is an existing AI Chatbot CRM that is being extended into a Telegram-first marketplace MVP.

Current system:
- Express backend
- React/Vite admin dashboard
- MongoDB/Mongoose current runtime
- Target Supabase/Postgres migration path
- Telegram webhook already exists
- WhatsApp/Instagram/Meta webhook exists
- AI agents exist
- Inbox/chats/messages exist
- Human takeover exists
- Contacts exist
- Legacy orders/complaints exist
- Local file storage exists

Target MVP:
Telegram user can browse products, add to cart, checkout, receive payment link, complete sandbox payment, receive paid notification, and admin can manage products/orders/payments/chats.

Main rules:
1. Do NOT rebuild from scratch.
2. Do NOT break existing CRM behavior.
3. Backend is source of truth for product, cart, checkout, order, and payment.
4. AI assists but must not mark payment as paid or override order/payment state.
5. Payment webhook must be verified and idempotent.
6. Every tenant-owned query must be workspace-scoped.
7. Do not expose secrets.
8. Do not add marketplace multi-seller features unless explicitly requested.
9. Do not implement payment before product/cart/checkout are deterministic.
10. Do not claim tests passed unless actually run.

Before coding, read these required docs in order:

1. docs/backend/index.md
2. docs/backend/brief/project-brief.md
3. docs/backend/brief/current-system-brief.md
4. docs/backend/brief/target-system-brief.md
5. docs/backend/brief/implementation-priority-brief.md
6. docs/backend/11-sprint/implementation-status.md
7. docs/backend/11-sprint/progress-log.md
8. docs/backend/11-sprint/current-sprint.md
9. docs/backend/11-sprint/backlog.md
10. docs/backend/11-sprint/task-breakdown.md
11. docs/backend/11-sprint/definition-of-done.md
12. docs/backend/09-ai-context/prompt-context.md
13. docs/backend/09-ai-context/current-task.md
14. docs/backend/09-ai-context/do-not-break.md
15. docs/backend/09-ai-context/coding-guidelines.md
16. docs/backend/09-ai-context/security-rules-for-ai.md
17. docs/backend/04-tech-spec/decision-log.md
18. docs/backend/04-tech-spec/architecture.md
19. docs/backend/04-tech-spec/coding-rules.md

Then read area-specific docs based on the task type.

If the task is API-related, read:
- docs/backend/05-api-spec/overview.md
- docs/backend/05-api-spec/error-format.md
- docs/backend/05-api-spec/api-versioning.md
- docs/backend/05-api-spec/rate-limits.md
- the specific API file related to the task

If the task is database/migration/entity-related, read:
- docs/backend/06-data/README.md
- docs/backend/06-data/database-schema.md
- docs/backend/06-data/entities.md
- docs/backend/06-data/relationships.md
- docs/backend/06-data/data-flow.md
- docs/backend/06-data/indexes.md
- docs/backend/06-data/rls-policies.md
- docs/backend/06-data/migration-plan.md
- docs/backend/06-data/storage-model.md

If the task is Telegram commerce-related, read:
- docs/backend/02-flows/telegram-commerce-flow.md
- docs/backend/02-flows/checkout-flow.md
- docs/backend/02-flows/payment-flow.md
- docs/backend/03-business-rules/telegram-commerce-rules.md
- docs/backend/03-business-rules/cart-checkout-rules.md
- docs/backend/05-api-spec/telegram-commerce-api.md
- docs/backend/07-uiux/telegram-bot-ux.md
- docs/backend/09-ai-context/telegram-bot-context.md

If the task is payment-related, read:
- docs/backend/02-flows/payment-flow.md
- docs/backend/03-business-rules/payment-rules.md
- docs/backend/05-api-spec/payments-api.md
- docs/backend/05-api-spec/webhooks-api.md
- docs/backend/08-security/payment-security.md
- docs/backend/10-testing/payment-test-plan.md
- docs/backend/12-ops/payment-ops.md

If the task is product/cart/checkout/order-related, read:
- docs/backend/02-flows/product-catalog-flow.md
- docs/backend/02-flows/checkout-flow.md
- docs/backend/03-business-rules/product-catalog-rules.md
- docs/backend/03-business-rules/cart-checkout-rules.md
- docs/backend/03-business-rules/order-rules.md
- docs/backend/05-api-spec/products-api.md
- docs/backend/05-api-spec/carts-api.md
- docs/backend/05-api-spec/checkout-api.md
- docs/backend/05-api-spec/orders-api.md
- docs/backend/06-data/database-schema.md

If the task is AI-related, read:
- docs/backend/04-tech-spec/ai-pipeline.md
- docs/backend/09-ai-context/ai-pipeline-rules.md
- docs/backend/09-ai-context/commerce-agent-guardrails.md
- docs/backend/09-ai-context/ai-action-contract.md
- docs/backend/09-ai-context/tool-calling-contract.md
- docs/backend/08-security/ai-prompt-security.md
- docs/backend/10-testing/ai-agent-evaluation.md

If the task is security-related, read:
- docs/backend/08-security/README.md
- docs/backend/08-security/api-security.md
- docs/backend/08-security/auth-authz.md
- docs/backend/08-security/workspace-tenant-security.md
- docs/backend/08-security/webhook-security.md
- docs/backend/08-security/payment-security.md
- docs/backend/08-security/secrets-env-policy.md
- docs/backend/08-security/security-checklist.md
- docs/backend/08-security/threat-model.md

If the task is UI/admin-dashboard-related, read:
- docs/backend/07-uiux/backend-ui-contract.md
- docs/backend/07-uiux/pages-backend-requirements.md
- docs/backend/07-uiux/admin-actions-matrix.md
- docs/backend/07-uiux/forms-and-fields.md
- docs/backend/07-uiux/data-table-actions.md
- docs/backend/07-uiux/workflow-buttons.md
- docs/backend/05-api-spec/overview.md

If the task is testing-related, read:
- docs/backend/10-testing/test-strategy.md
- docs/backend/10-testing/unit-test-plan.md
- docs/backend/10-testing/integration-test-plan.md
- docs/backend/10-testing/e2e-test-plan.md
- docs/backend/10-testing/regression-checklist.md
- docs/backend/10-testing/acceptance-test-cases.md
- docs/backend/10-testing/smoke-test-checklist.md
- docs/backend/11-sprint/definition-of-done.md

If the task is deployment/ops-related, read:
- docs/backend/12-ops/production-readiness.md
- docs/backend/12-ops/deployment-runbook.md
- docs/backend/12-ops/release-runbook.md
- docs/backend/12-ops/rollback-runbook.md
- docs/backend/12-ops/backup-restore-runbook.md
- docs/backend/12-ops/monitoring-alerting.md
- docs/backend/12-ops/troubleshooting.md

After reading the docs, respond first with:
1. What docs you read
2. Your understanding of the current project state
3. The exact task scope
4. Files likely to change
5. Risks
6. Test plan
7. Confirmation that you will preserve the do-not-break rules

Only then begin implementation.

When finished, respond with:
1. Summary
2. Files changed
3. Implementation notes
4. Tests run or not run
5. Risks remaining
6. Next recommended step
```

---

## Short Prompt Version

Use this for small tasks.

```txt
Before coding, read:
1. docs/backend/index.md
2. docs/backend/brief/project-brief.md
3. docs/backend/brief/current-system-brief.md
4. docs/backend/brief/implementation-priority-brief.md
5. docs/backend/11-sprint/implementation-status.md
6. docs/backend/11-sprint/current-sprint.md
7. docs/backend/11-sprint/task-breakdown.md
8. docs/backend/09-ai-context/do-not-break.md
9. docs/backend/09-ai-context/coding-guidelines.md
10. docs/backend/11-sprint/definition-of-done.md

Then read the specific docs for the task area.

Do not code before summarizing:
- current state
- task scope
- files likely to change
- risks
- test plan
- do-not-break rules
```

---

## Area-Specific Reading Matrix

| Task Type | Required Docs |
|---|---|
| API | `05-api-spec/overview.md`, `error-format.md`, related API file |
| Database | `06-data/database-schema.md`, `entities.md`, `relationships.md`, `migration-plan.md` |
| Product | `01-product/requirements.md`, `feature-list.md`, `mvp-scope.md`, `products-api.md` |
| Flow | `02-flows/*` related to task |
| Business Logic | `03-business-rules/*` related to task |
| Telegram | `02-flows/telegram-commerce-flow.md`, `05-api-spec/telegram-commerce-api.md`, `07-uiux/telegram-bot-ux.md` |
| Payment | `payment-flow.md`, `payment-rules.md`, `payments-api.md`, `payment-security.md`, `payment-test-plan.md` |
| AI | `ai-pipeline.md`, `ai-pipeline-rules.md`, `commerce-agent-guardrails.md`, `ai-action-contract.md` |
| UI/Admin | `07-uiux/backend-ui-contract.md`, `pages-backend-requirements.md`, `admin-actions-matrix.md` |
| Security | `08-security/api-security.md`, `auth-authz.md`, `webhook-security.md`, `payment-security.md` |
| Testing | `10-testing/test-strategy.md`, `regression-checklist.md`, `definition-of-done.md` |
| Ops | `12-ops/deployment-runbook.md`, `rollback-runbook.md`, `backup-restore-runbook.md` |

## Required Pre-Coding Checklist

Before implementation, AI agent/dev must answer:

```txt
[ ] What is the current project state?
[ ] What exact task am I doing?
[ ] Which docs did I read?
[ ] Which files are likely to change?
[ ] What existing behavior must not break?
[ ] What security risks exist?
[ ] What tests should be run?
[ ] What is the Definition of Done?
```

## Required Post-Coding Checklist

After implementation, AI agent/dev must answer:

```txt
[ ] What changed?
[ ] Which files changed?
[ ] Did any API/schema/business rule change?
[ ] Were docs updated?
[ ] Were tests run?
[ ] If tests were not run, why?
[ ] What risks remain?
[ ] What should be done next?
```

## Deprecated Docs Warning

Do not follow unrelated old project docs unless explicitly requested.

Examples that should not be treated as core for this backend:

```txt
encyclopedias-api.md
assets-api.md
exports-api.md
image-generation QA docs
cliproxy docs
```

This backend focuses on:

```txt
CRM
Telegram commerce
Product/cart/checkout/order/payment
AI assistant
webhooks
workspace security
database migration
admin operations
```
