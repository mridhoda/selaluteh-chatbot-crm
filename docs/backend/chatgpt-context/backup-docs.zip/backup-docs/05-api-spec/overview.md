# API Overview

## Purpose

Backend API melayani tiga jenis client:

1. **Admin dashboard** — React/Vite CRM admin.
2. **External webhook providers** — Telegram, Meta/WhatsApp/Instagram, payment gateway.
3. **Internal workers** — background jobs, AI reply processing, payment sync.

## Recommended API Prefix

New endpoint:

```txt
/api/v1/*
```

Legacy endpoint yang sudah ada boleh dipertahankan sementara:

```txt
/auth
/users
/platforms
/agents
/chats
/orders
/complaints
/webhook
```

Migration target:

```txt
legacy route -> route adapter -> v1 service layer
```

## Authentication

Dashboard API memakai JWT Bearer token.

```http
Authorization: Bearer <jwt>
```

JWT payload minimal:

```json
{
  "id": "user_uuid",
  "email": "owner@example.com"
}
```

Backend harus resolve user dari database, lalu attach:

```txt
req.user.id
req.user.workspace_id
req.user.role
```

## Workspace Scoping

Semua endpoint tenant-owned wajib scoped by `workspace_id`.

Rules:

- User hanya boleh membaca data dalam workspace sendiri.
- Role `owner` dan `super` boleh melihat semua data workspace.
- Role `agent` hanya boleh melihat chat yang assigned/taken over sesuai policy.
- Webhook routes public secara HTTP, tapi platform harus diverifikasi dari token/account/provider signature.

## Response Shape

Success response:

```json
{
  "success": true,
  "data": {},
  "meta": {}
}
```

List response:

```json
{
  "success": true,
  "data": [],
  "meta": {
    "limit": 50,
    "cursor": "next_cursor",
    "has_more": true
  }
}
```

Error response dijelaskan di `error-format.md`.

## Pagination

Recommended cursor pagination:

```txt
?limit=50&cursor=<opaque_cursor>
```

For migration compatibility, some old endpoints may still use:

```txt
?page=1&limit=50
```

Preferred sort for inbox/order/history:

```txt
created_at desc
last_message_at desc
```

## Idempotency

Idempotency wajib untuk:

- Telegram webhook updates.
- Meta webhook messages.
- Payment gateway webhooks.
- Checkout creation.
- Payment link creation.

Client-supplied idempotency header for dashboard actions:

```http
Idempotency-Key: checkout_019...
```

Provider webhook idempotency uses:

```txt
provider + event_id
platform + platform_message_id
payment_provider + provider_transaction_id + event_type
```

## Content Types

JSON API:

```http
Content-Type: application/json
```

File upload:

```http
Content-Type: multipart/form-data
```

Webhook providers may send provider-specific payloads. Store raw payload in `webhook_events.raw_payload` before processing.

## Status Code Convention

| Code | Meaning |
|---|---|
| 200 | OK |
| 201 | Created |
| 202 | Accepted, async processing |
| 204 | No content |
| 400 | Validation error |
| 401 | Missing/invalid auth |
| 403 | Authenticated but forbidden |
| 404 | Resource not found or not accessible |
| 409 | Conflict/idempotency duplicate/business conflict |
| 422 | Valid request shape but business rule failed |
| 429 | Rate limit |
| 500 | Internal error |
