# Orders API

## Purpose

Manage both legacy AI form orders and new marketplace orders.

## Order Sources

```txt
ai_form
telegram
admin
manual
```

## Order Status

Recommended enum:

```txt
new
pending_payment
paid
processed
ready
completed
cancelled
expired
refunded
```

Legacy status compatibility:

```txt
new
processed
completed
cancelled
```

## GET `/api/v1/orders`

List orders in current workspace.

Auth required.

### Query

| Param | Type | Notes |
|---|---|---|
| `status` | string | optional |
| `source` | string | ai_form/telegram/admin/manual |
| `contact_id` | uuid | optional |
| `chat_id` | uuid | optional |
| `payment_status` | string | optional join/filter |
| `from` | datetime | optional |
| `to` | datetime | optional |
| `limit` | number | default 50 |
| `cursor` | string | pagination |

### Response

```json
{
  "success": true,
  "data": [
    {
      "id": "019...",
      "order_number": "ORD-20260612-0001",
      "source": "telegram",
      "status": "pending_payment",
      "contact": {
        "id": "019...",
        "name": "Customer"
      },
      "total_amount": 50000,
      "currency": "IDR",
      "payment_status": "pending",
      "created_at": "2026-06-12T00:00:00Z"
    }
  ]
}
```

## GET `/api/v1/orders/:order_id`

Return order detail including items, payment, chat/contact.

### Response

```json
{
  "success": true,
  "data": {
    "id": "019...",
    "order_number": "ORD-20260612-0001",
    "source": "telegram",
    "status": "paid",
    "items": [
      {
        "product_id": "019...",
        "variant_id": "019...",
        "name_snapshot": "Salty Caramel",
        "unit_price": 25000,
        "quantity": 2,
        "line_total": 50000
      }
    ],
    "payments": [
      {
        "id": "019...",
        "provider": "midtrans",
        "status": "settlement",
        "amount": 50000,
        "payment_link_url": "https://..."
      }
    ]
  }
}
```

## POST `/api/v1/orders`

Manual/admin order creation.

Auth required.

### Request

```json
{
  "contact_id": "019...",
  "chat_id": "019...",
  "source": "manual",
  "items": [
    {
      "product_id": "019...",
      "variant_id": "019...",
      "quantity": 2
    }
  ],
  "notes": "Manual order from admin"
}
```

## PATCH `/api/v1/orders/:order_id/status`

Update order status.

Auth required.

### Request

```json
{
  "status": "processed",
  "notes": "Order is being prepared."
}
```

### Rules

- Cannot move `cancelled` order to `paid` manually.
- Payment status should be updated by payment webhook, not admin status endpoint.
- Status transition must follow business rules.

## POST `/api/v1/orders/:order_id/cancel`

Cancel order.

### Request

```json
{
  "reason": "Customer cancelled before payment."
}
```

## Legacy Compatibility

Existing legacy routes must become auth + workspace scoped:

```txt
GET /orders
PUT /orders/:id
PUT /orders/:id/cancel
DELETE /orders/:id
```

They should delegate to v1 service layer.
