# Payments API

## Purpose

Create payment links, track payment status, handle payment gateway webhooks, and update orders.

MVP target providers:

```txt
midtrans
xendit
manual
```

## Payment Status

Internal normalized status:

```txt
pending
requires_action
paid
failed
expired
cancelled
refunded
```

Provider raw statuses must be stored in `payments.provider_status` and `payment_events.raw_payload`.

## POST `/api/v1/payments`

Create payment transaction/link for pending order.

Auth required for dashboard. Internal bot flow can call service layer after checkout confirmation.

### Headers

```http
Idempotency-Key: pay_order_019...
```

### Request

```json
{
  "order_id": "019...",
  "provider": "midtrans",
  "method": "payment_link"
}
```

### Response

```json
{
  "success": true,
  "data": {
    "payment_id": "019...",
    "order_id": "019...",
    "provider": "midtrans",
    "status": "pending",
    "amount": 50000,
    "currency": "IDR",
    "payment_link_url": "https://app.sandbox.midtrans.com/snap/v2/vtweb/...",
    "expires_at": "2026-06-12T01:00:00Z"
  }
}
```

### Side Effects

- Insert `payments`.
- Store provider transaction id.
- Store payment link URL.
- Keep order `pending_payment` until webhook confirms paid.

## GET `/api/v1/payments/:payment_id`

Return payment detail.

Auth required.

## GET `/api/v1/orders/:order_id/payments`

List payments for order.

Auth required.

## POST `/api/v1/payments/:payment_id/sync`

Optional admin/manual sync with provider.

Auth: owner/super.

### Response

```json
{
  "success": true,
  "data": {
    "payment_id": "019...",
    "old_status": "pending",
    "new_status": "paid"
  }
}
```

## POST `/api/v1/payments/:payment_id/cancel`

Cancel payment if provider supports it.

Auth: owner/super.

## Payment Webhook

Public provider endpoint is documented in `webhooks-api.md`.

```txt
POST /webhook/payments/:provider
```

## Webhook Processing Rules

On payment webhook:

1. Verify provider signature.
2. Insert `webhook_events` idempotently.
3. Find payment by provider transaction id/order id.
4. Insert `payment_events`.
5. Normalize provider status.
6. Update `payments.status`.
7. If paid, update `orders.status = paid`.
8. Notify customer on Telegram/WhatsApp if possible.

## Security Rules

- Never trust client to mark payment paid.
- Never update paid amount from client request.
- Payment success must come from verified gateway webhook or trusted provider sync.
- Store raw payload for audit.
