# Products API

## Purpose

Manage marketplace product catalog for Telegram commerce MVP.

## GET `/api/v1/product-categories`

List product categories.

Auth required for admin dashboard. Public/internal bot access allowed via service layer.

### Response

```json
{
  "success": true,
  "data": [
    {
      "id": "019...",
      "name": "Coffee",
      "slug": "coffee",
      "description": "Coffee drinks",
      "sort_order": 1,
      "is_active": true
    }
  ]
}
```

## POST `/api/v1/product-categories`

Auth: owner/super.

### Request

```json
{
  "name": "Coffee",
  "slug": "coffee",
  "description": "Coffee drinks",
  "sort_order": 1,
  "is_active": true
}
```

## GET `/api/v1/products`

List products.

Auth required for dashboard. Bot/service can call internal repository.

### Query

| Param | Type | Notes |
|---|---|---|
| `category_id` | uuid | optional |
| `search` | string | product name/description |
| `is_active` | boolean | optional |
| `available_for_telegram` | boolean | optional |
| `limit` | number | default 50 |
| `cursor` | string | pagination |

### Response

```json
{
  "success": true,
  "data": [
    {
      "id": "019...",
      "category_id": "019...",
      "name": "Salty Caramel",
      "slug": "salty-caramel",
      "description": "Iced coffee with salty caramel flavor.",
      "base_price": 25000,
      "currency": "IDR",
      "is_active": true,
      "available_for_telegram": true,
      "images": [
        {
          "id": "019...",
          "public_path": "/files/product-images/2026/06/photo.jpg"
        }
      ],
      "variants": [
        {
          "id": "019...",
          "name": "Regular",
          "price": 25000,
          "stock_quantity": 100,
          "is_active": true
        }
      ]
    }
  ]
}
```

## GET `/api/v1/products/:product_id`

Return product detail.

## POST `/api/v1/products`

Auth: owner/super.

### Request

```json
{
  "category_id": "019...",
  "name": "Salty Caramel",
  "slug": "salty-caramel",
  "description": "Iced salty caramel coffee.",
  "base_price": 25000,
  "currency": "IDR",
  "is_active": true,
  "available_for_telegram": true
}
```

## PATCH `/api/v1/products/:product_id`

Auth: owner/super.

## DELETE `/api/v1/products/:product_id`

Auth: owner/super.

Recommended: soft-delete / set `is_active=false` if product has orders.

## POST `/api/v1/products/:product_id/variants`

Create product variant.

Auth: owner/super.

### Request

```json
{
  "name": "Large",
  "sku": "SLTY-L",
  "price": 30000,
  "stock_quantity": 50,
  "is_active": true
}
```

## PATCH `/api/v1/products/:product_id/variants/:variant_id`

Update variant.

## POST `/api/v1/products/:product_id/images`

Upload product image.

Auth: owner/super.
Content-Type: multipart/form-data.

Writes:

```txt
files
product_images
```

## Business Rules

- Product must belong to current workspace.
- Inactive products cannot be added to cart.
- Inactive variants cannot be added to cart.
- Price copied into `cart_items` and `order_items` at time of action to preserve historical pricing.
