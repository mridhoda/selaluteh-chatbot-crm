# Prompt Context

Dokumen ini adalah context utama untuk AI coding agent yang bekerja di codebase backend.

## Identity

Project ini adalah backend untuk **SelaluTeh Chatbot CRM / Telegram-first Marketplace MVP**.

Backend existing menggunakan:

```txt
Express.js
MongoDB/Mongoose
Telegram webhook
Meta webhook for WhatsApp/Instagram
OpenAI/Gemini AI reply
local file uploads
React/Vite admin dashboard frontend
```

Target baru:

```txt
Supabase/Postgres data layer
repository abstraction
Telegram commerce MVP
product catalog
cart
checkout
order_items
payment gateway sandbox
payment webhook
workspace-based multi-tenancy
local media storage retained
```

## Primary Goal

Jangan rebuild project dari nol. Lanjutkan sistem existing dengan cara:

1. Hardening security existing routes.
2. Menambahkan repository layer.
3. Menjaga behavior CRM/chatbot existing.
4. Menambahkan marketplace modules secara bertahap.
5. Memastikan AI tidak menjadi sumber kebenaran untuk order/payment.

## Critical Existing Behaviors

AI agent sudah bisa:

- menerima message dari Telegram webhook,
- menyimpan contact/chat/message,
- membaca chat history,
- menghormati human takeover,
- mengirim balasan ke Telegram,
- membuat order/complaint legacy via marker AI,
- escalate ke human.

Behavior ini harus tetap berjalan selama refactor.

## New Marketplace Behaviors

Sistem baru harus mendukung:

```txt
/start menu
browse products
product detail
add to cart
view cart
checkout confirmation
create pending order
create payment link
receive payment webhook
mark order paid
notify Telegram user
admin manage product/order/payment
```

## AI Agent Working Rule

AI coding agent harus:

- membaca docs terkait sebelum implementasi,
- tidak menghapus fitur existing tanpa alasan,
- tidak mengubah API response shape tanpa update docs,
- tidak menaruh secret di kode,
- tidak memindahkan file binary ke Postgres,
- tidak menjalankan migration production tanpa instruksi eksplisit,
- selalu menambahkan test atau minimal manual test checklist untuk flow kritis.
