<!--
Tech Spec Pack: Telegram-first Marketplace Backend
Project: KALIS.AI / eskala-bot evolution
Target: Chatbot CRM + Telegram Marketplace MVP
Generated: 2026-06-11
-->

# Backend Architecture

## Overview

The backend evolves from a chatbot CRM into a commerce-enabled chatbot platform.

```txt
Telegram / WhatsApp / Instagram
        ↓ webhook
Express API Gateway
        ↓
Webhook Idempotency Layer
        ↓
Platform Service
        ↓
Contact + Chat Service
        ↓
Message Service
        ↓
AI Orchestrator / Commerce Intent Router
        ↓
Marketplace Services
  ├─ Product Service
  ├─ Cart Service
  ├─ Checkout Service
  ├─ Order Service
  ├─ Payment Service
  └─ Notification Service
        ↓
Supabase PostgreSQL + Local File Storage
```

## Runtime Components

| Component | Responsibility |
|---|---|
| API Server | REST APIs, dashboard APIs, webhooks |
| Webhook Handler | Telegram/Meta/payment inbound processing |
| Worker | AI generation, payment retry, notifications, follow-ups |
| Repository Layer | Database abstraction for Mongo → Supabase transition |
| Local Storage Service | File metadata + local file path management |
| Payment Service | Payment link creation and webhook verification |
| AI Orchestrator | LLM prompt, tool/action proposal, response formatting |

## Request Types

### 1. Admin Dashboard API

```txt
Browser
  -> React/Vite dashboard
  -> Express REST API with JWT
  -> Workspace-scoped repository
  -> Supabase/Postgres
```

### 2. Telegram Webhook

```txt
Telegram update
  -> POST /webhook/telegram/:token?
  -> verify platform/token
  -> store webhook_events
  -> upsert contact/chat
  -> insert user message
  -> run commerce command or AI response
  -> send Telegram response
  -> insert outgoing message
```

### 3. Payment Webhook

```txt
Payment provider webhook
  -> POST /webhook/payments/:provider
  -> verify signature
  -> store payment_events
  -> update payments
  -> update orders
  -> notify Telegram user
```

## Core Domain Boundaries

### CRM Domain

- contacts
- chats
- messages
- human takeover
- complaints
- inbox filters

### AI Agent Domain

- agents
- knowledge
- prompt behavior
- files/database
- AI actions
- escalation

### Marketplace Domain

- products
- categories
- variants
- carts
- cart items
- checkouts
- orders
- order items
- payments
- payment events

### Integration Domain

- Telegram platform
- Meta WhatsApp/Instagram
- payment providers
- webhooks

## Important State Ownership

| State | Source of Truth |
|---|---|
| Product price | `products` / `product_variants` |
| Cart content | `carts` + `cart_items` |
| Order total | `orders` + `order_items` snapshot |
| Payment status | `payments` updated by provider webhook |
| Chat assignment | `chats.takeover_by` |
| AI suggested action | `ai_actions`, not final state |
| File binary | local filesystem |
| File metadata | `files` table |

## AI vs Deterministic Flow

Commerce must not depend on free-text AI output alone.

Bad:

```txt
AI says user wants 3 products -> immediately create paid order
```

Good:

```txt
AI detects likely intent
  -> backend asks confirmation using Telegram button
  -> user taps button
  -> backend validates and updates cart/order
```

## Failure Handling

| Failure | Expected Handling |
|---|---|
| Telegram duplicate webhook | Ignore based on `webhook_events` or `platform_message_id` |
| AI timeout | Send fallback reply and log error |
| Payment provider timeout | Keep payment pending, retry provider lookup |
| Payment duplicate webhook | Store event once, update idempotently |
| Local file missing | Keep metadata, mark file status missing in validation |
| Human takeover active | Skip AI reply |
