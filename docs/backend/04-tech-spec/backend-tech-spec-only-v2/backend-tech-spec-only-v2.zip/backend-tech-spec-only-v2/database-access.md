<!--
Tech Spec Pack: Telegram-first Marketplace Backend
Project: KALIS.AI / eskala-bot evolution
Target: Chatbot CRM + Telegram Marketplace MVP
Generated: 2026-06-11
-->

# Database Access and Repository Layer

## Goal

Create a data access layer that allows the backend to migrate from MongoDB/Mongoose to Supabase/Postgres without rewriting every route at once.

## Main Principles

1. Route code must not directly call Mongoose or Supabase.
2. Services use repositories.
3. Repositories enforce workspace scoping.
4. All writes that affect commerce state must be transactional when possible.
5. Payment state changes must be idempotent.

## Repository Interface Pattern

Example interface shape:

```js
const productsRepository = {
  listByWorkspace({ workspaceId, filters, limit, cursor }) {},
  findById({ workspaceId, productId }) {},
  create({ workspaceId, createdBy, data }) {},
  update({ workspaceId, productId, data }) {},
  archive({ workspaceId, productId }) {}
}
```

## Required Repositories

| Repository | Purpose |
|---|---|
| `users.repository` | Login, profile, role lookup |
| `workspaces.repository` | Workspace ownership and setup |
| `platforms.repository` | Telegram/Meta platform lookup |
| `agents.repository` | AI agent config lookup |
| `contacts.repository` | Platform user identity upsert |
| `chats.repository` | Conversation state |
| `messages.repository` | Message history |
| `products.repository` | Product catalog |
| `carts.repository` | Telegram cart/session state |
| `checkouts.repository` | Checkout state and totals |
| `orders.repository` | Orders and order items |
| `payments.repository` | Payments and payment events |
| `files.repository` | File metadata |
| `webhook-events.repository` | Idempotency |
| `ai-actions.repository` | AI action proposals/executions |

## Workspace Scoping

Every repository method for tenant-owned data must accept `workspaceId`.

Good:

```js
findChatById({ workspaceId, chatId })
```

Bad:

```js
findChatById(chatId)
```

## Transaction Boundaries

Use database transaction/RPC for flows that must stay consistent:

### Checkout

```txt
validate cart
create checkout
create order
create order_items snapshot
create payment pending
```

### Payment Webhook

```txt
insert payment_event
update payment status
update order status
insert notification job
```

## Idempotency Keys

Use unique keys for repeated events:

| Event | Suggested Idempotency Key |
|---|---|
| Telegram message | `telegram:update_id` or `platform_message_id` |
| Telegram callback | `callback_query.id` |
| Meta message | provider message id |
| Payment webhook | provider event id or `provider + transaction_id + status` |
| AI action execution | `ai_action.id` |

## Postgres vs Service Role

If backend uses Supabase service role, RLS can be bypassed. Therefore backend code must still validate:

- `workspace_id`
- user role
- chat assignment
- platform ownership
- product ownership
- order/payment ownership

## Query Contracts to Preserve

- `GET /chats` must sort by `last_message_at desc`.
- `GET /chats/:id/messages` must return messages ascending.
- Telegram webhook must upsert contact by workspace + platform identity.
- Chat must upsert by workspace + platform + contact.
- Orders/complaints must be auth required and workspace-scoped.

## Marketplace Query Requirements

### Product List

```txt
workspace_id
status=active
category optional
search optional
sort by display_order, name
```

### Cart Load

```txt
workspace_id
contact_id or chat_id
status=active
include cart_items + product/variant snapshot
```

### Order List

```txt
workspace_id
status optional
payment_status optional
contact optional
created_at desc
```

### Payment Events

```txt
payment_id
provider
created_at asc
```
