<!--
Tech Spec Pack: Telegram-first Marketplace Backend
Project: KALIS.AI / eskala-bot evolution
Target: Chatbot CRM + Telegram Marketplace MVP
Generated: 2026-06-11
-->

# Decision Log

## D001 — Continue Existing Project, Do Not Rebuild

Decision: Continue current Chatbot CRM codebase and evolve it into Telegram-first marketplace.

Reason:

- Telegram webhook already exists.
- AI agents already exist.
- CRM inbox and human takeover already exist.
- Dashboard already exists.

Consequence:

- Need incremental migration and service cleanup.

## D002 — Supabase/Postgres as Target Data Layer

Decision: Move structured data from MongoDB/Mongoose to Supabase/Postgres.

Reason:

- Marketplace needs relational consistency.
- Workspace isolation is easier with RLS and `workspace_id`.
- Orders/payments/order items need strong query/reporting support.

Consequence:

- Need migration scripts and repository layer.

## D003 — Keep Local File Storage for MVP

Decision: Store media binaries on local server filesystem, store metadata in Postgres.

Reason:

- Existing app already uses `server/uploads`.
- Lower storage/egress cost.
- Easier migration.

Consequence:

- Must implement backup and persistent volume strategy.

## D004 — AI Is Assistant, Backend Is Source of Truth

Decision: AI can propose actions, but backend validates and executes commerce/payment state.

Reason:

- Prevent hallucinated orders/prices/payment statuses.
- Keep checkout deterministic.

Consequence:

- Need `ai_actions` and service validation.

## D005 — Telegram First, Single Merchant MVP

Decision: MVP is single-merchant Telegram commerce, not multi-seller marketplace.

Reason:

- Faster validation.
- Existing workspace model fits single merchant.
- Multi-seller adds commission, payout, dispute complexity.

Consequence:

- Tables can be designed with future extensibility but MVP UI/API stays single merchant.

## D006 — Payment Gateway Sandbox Before Production Payment

Decision: Use Midtrans sandbox first.

Reason:

- Indonesian context.
- Payment simulator useful for testing.
- Payment link flow fits Telegram.

Consequence:

- Need payment webhook verification and provider status mapping.

## D007 — Webhook Idempotency Is Required

Decision: Store webhook events and deduplicate provider messages/events.

Reason:

- Telegram/Meta/payment providers can retry webhooks.
- Duplicate messages/payments/orders are dangerous.

Consequence:

- Add `webhook_events` and unique keys.

## D008 — Repository Layer Before Full Migration

Decision: Add repository layer before changing every route to Supabase.

Reason:

- Reduces migration risk.
- Allows route-by-route cutover.

Consequence:

- More upfront structure, less chaos later.
