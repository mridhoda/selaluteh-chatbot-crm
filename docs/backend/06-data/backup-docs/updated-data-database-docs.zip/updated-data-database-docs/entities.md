# Entities — Current to Target Mapping

Dokumen ini menjelaskan entity data utama backend sekarang, target representasi di Supabase/Postgres, dan entity baru untuk Telegram-first Marketplace MVP.

## Current Mongoose to Target Postgres

| Current Mongoose Model | Target Table | Catatan |
|---|---|---|
| `User` | `users` | App user, bukan hanya Supabase Auth user |
| implicit workspace ObjectId | `workspaces` | Saat ini hanya `workspaceId`; target eksplisit |
| `Platform` | `platforms` | Telegram/WhatsApp/Instagram credentials |
| `Agent` | `agents` + child tables | Nested arrays dinormalisasi |
| `Knowledge` | `files` + `agent_knowledge` | File metadata dan knowledge agent |
| `Contact` | `contacts` | Customer identity per platform |
| `Chat` | `chats` | Conversation state |
| `Message` | `messages` | Riwayat pesan |
| `Order` | `orders` + `order_items` | Legacy form order + marketplace order |
| `Complaint` | `complaints` | Keluhan customer |
| `OTP` | `otps` | Verifikasi register |
| `PasswordReset` | `password_resets` | Reset password |
| `Setting` | `settings` | Preferensi AI/commerce/payment |

## New Marketplace Entities

| Entity | Table | Purpose |
|---|---|---|
| Product Category | `product_categories` | Grouping product |
| Product | `products` | Catalog utama |
| Product Variant | `product_variants` | Size/flavor/options |
| Cart | `carts` | Shopping session aktif |
| Cart Item | `cart_items` | Item sebelum checkout |
| Order Item | `order_items` | Snapshot item setelah checkout |
| Payment | `payments` | Payment link/status |
| Payment Event | `payment_events` | Riwayat webhook payment |
| Webhook Event | `webhook_events` | Idempotency Telegram/Meta/payment |

## Workspace

Workspace adalah tenant boundary utama. Semua operational table wajib punya `workspace_id`.

Target fields:

```txt
id
name
owner_user_id
metadata
created_at
updated_at
```

Rules:

- Satu user berada dalam satu workspace.
- Query isolation harus pakai `workspace_id`, bukan hanya `owner_user_id`.
- `owner_user_id` boleh dipakai untuk compatibility.

## Users

App operator/admin/human agent.

Fields:

```txt
id, auth_user_id, workspace_id, name, email, password_hash, role,
verified, status, plan, plan_expiry, last_login_at, metadata
```

Custom JWT auth boleh tetap pakai `password_hash`. `auth_user_id` disiapkan jika nanti pindah ke Supabase Auth penuh.

## Platforms

Mewakili channel yang terhubung:

- Telegram bot
- WhatsApp account
- Instagram account
- Facebook/custom

Sensitive fields seperti `token`, `app_secret`, `webhook_secret` harus dianggap secret.

## Agents

Agent adalah konfigurasi AI assistant. Karena model lama terlalu banyak nested array, target memecah menjadi:

```txt
agents
agent_knowledge
agent_database_files
agent_followups
agent_complaint_fields
agent_outlets
agent_sales_forms
agent_sales_form_fields
agent_sales_form_products
agent_products
```

`agent_products` dan `agent_sales_form_products` dipakai sebagai bridge dari sistem lama. Marketplace baru harus memakai `products`.

## Contacts

Customer eksternal dari Telegram/WA/Instagram.

Unique identity:

```txt
workspace_id + platform_type + platform_account_id
```

Ini mencegah contact duplicate ketika webhook dikirim berulang.

## Chats

Conversation thread. `chats.state` boleh menyimpan temporary state seperti:

```json
{
  "awaiting": "delivery_address",
  "checkout_cart_id": "..."
}
```

Tetapi cart item tidak boleh disimpan di `chats.state`; cart harus relational di `carts` dan `cart_items`.

## Messages

History pesan. Field lama `from` sebaiknya menjadi `sender` karena `from` membingungkan di SQL.

Attachment target jangka panjang:

```txt
messages.attachment_file_id -> files.id
```

Legacy JSONB `messages.attachment` tetap disimpan sementara.

## Files

Metadata file lokal. Binary tetap ada di local filesystem.

Sumber file:

```txt
platform_inbound
crm_upload
agent_database
payment_proof
product_image
ai_generated
external_download
public_asset
```

## Products

Canonical product catalog. AI dan Telegram commerce harus membaca dari table ini, bukan dari nested agent form.

Important rule:

```txt
Historical order tidak boleh dihitung dari harga product saat ini.
```

Karena itu cart/order menyimpan price snapshot.

## Product Variants

Dipakai untuk opsi seperti size, flavor, package, add-on.

Jika variant price null, fallback ke product base price.

## Carts

Cart adalah shopping state sebelum order. Rule MVP:

```txt
one active cart per workspace + contact + platform_type
```

## Cart Items

Menyimpan quantity, unit_price, total_price, dan product_snapshot.

Backend wajib resolve price dari DB, bukan dari callback Telegram.

## Orders

Order mendukung dua jenis:

1. legacy `ai_form` order dari `FILE_ORDER_JSON`
2. new `telegram_marketplace` order dari checkout deterministic

`orders.status` dan `orders.payment_status` dipisah.

## Order Items

Snapshot final item yang dibeli. Harus tetap readable walaupun product sudah diubah/dihapus.

## Payments

Payment attempt/link. Satu order bisa punya lebih dari satu payment attempt, tetapi MVP cukup satu active pending payment.

## Payment Events

Audit log untuk webhook payment provider. Selalu simpan raw payload untuk debugging dan reconciliation.

## Webhook Events

Audit/idempotency untuk webhook umum. Telegram harus memakai `update_id` atau message id untuk menghindari duplicate processing.
