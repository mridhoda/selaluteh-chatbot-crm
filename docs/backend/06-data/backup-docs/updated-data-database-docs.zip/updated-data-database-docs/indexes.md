# Indexes

Index ini dirancang untuk query paling sering di CRM, Telegram webhook, marketplace MVP, dan payment webhook.

## Identity

```sql
create unique index users_email_unique on users (email);
create index users_workspace_id_idx on users (workspace_id);
create index users_auth_user_id_idx on users (auth_user_id);
create index users_workspace_role_idx on users (workspace_id, role);
```

## Platforms

```sql
create index platforms_workspace_id_idx on platforms (workspace_id);
create index platforms_workspace_type_idx on platforms (workspace_id, type);
create index platforms_account_lookup_idx on platforms (type, account_id);
create index platforms_token_lookup_idx on platforms (type, token);
create index platforms_enabled_idx on platforms (workspace_id, enabled);
```

## Webhook Events

```sql
create index webhook_events_workspace_received_idx on webhook_events (workspace_id, received_at desc);
create unique index webhook_events_provider_external_unique on webhook_events (provider, external_event_id) where external_event_id is not null;
create index webhook_events_payload_hash_idx on webhook_events (provider, payload_hash);
create index webhook_events_status_idx on webhook_events (status, received_at desc);
```

## Agents

```sql
create index agents_workspace_id_idx on agents (workspace_id);
create index agents_platform_id_idx on agents (platform_id);
create index agents_workspace_active_idx on agents (workspace_id, is_active);
create index agent_knowledge_agent_idx on agent_knowledge (agent_id);
create index agent_database_files_agent_idx on agent_database_files (agent_id);
create index agent_followups_agent_enabled_idx on agent_followups (agent_id, enabled);
create index agent_sales_forms_agent_idx on agent_sales_forms (agent_id);
create index agent_products_agent_idx on agent_products (agent_id);
```

## Contacts

```sql
create index contacts_workspace_id_idx on contacts (workspace_id);
create unique index contacts_platform_identity_unique on contacts (workspace_id, platform_type, platform_account_id);
create index contacts_tags_gin_idx on contacts using gin (tags);
create index contacts_last_seen_idx on contacts (workspace_id, last_seen desc);
create index contacts_name_trgm_idx on contacts using gin (name gin_trgm_ops);
create index contacts_handle_trgm_idx on contacts using gin (handle gin_trgm_ops);
```

## Chats

```sql
create index chats_workspace_last_message_idx on chats (workspace_id, last_message_at desc);
create index chats_contact_id_idx on chats (contact_id);
create index chats_platform_contact_idx on chats (workspace_id, platform_id, contact_id);
create index chats_takeover_by_idx on chats (workspace_id, takeover_by);
create index chats_status_idx on chats (workspace_id, status);
create index chats_unread_idx on chats (workspace_id, unread);
create index chats_escalated_idx on chats (workspace_id, is_escalated);
create index chats_agent_idx on chats (workspace_id, agent_id);
```

## Messages

```sql
create index messages_chat_created_idx on messages (chat_id, created_at);
create index messages_workspace_created_idx on messages (workspace_id, created_at desc);
create index messages_platform_message_id_idx on messages (platform_message_id);
create index messages_reply_to_idx on messages (reply_to);
create index messages_attachment_file_idx on messages (attachment_file_id);
create unique index messages_chat_platform_message_unique on messages (chat_id, platform_message_id) where platform_message_id is not null;
create index messages_text_trgm_idx on messages using gin (text gin_trgm_ops);
```

## Files

```sql
create index files_workspace_id_idx on files (workspace_id);
create unique index files_disk_relative_path_unique on files (disk, relative_path);
create index files_public_path_idx on files (public_path);
create index files_source_idx on files (workspace_id, source, created_at desc);
```

## Products

```sql
create index product_categories_workspace_idx on product_categories (workspace_id);
create unique index product_categories_workspace_slug_unique on product_categories (workspace_id, slug);
create index product_categories_active_sort_idx on product_categories (workspace_id, is_active, sort_order);

create index products_workspace_idx on products (workspace_id);
create unique index products_workspace_slug_unique on products (workspace_id, slug);
create unique index products_workspace_sku_unique on products (workspace_id, sku) where sku is not null;
create index products_category_idx on products (workspace_id, category_id);
create index products_active_sort_idx on products (workspace_id, is_active, sort_order, created_at desc);
create index products_featured_idx on products (workspace_id, is_featured, is_active);
create index products_name_trgm_idx on products using gin (name gin_trgm_ops);
create index products_description_trgm_idx on products using gin (description gin_trgm_ops);

create index product_variants_product_idx on product_variants (product_id);
create index product_variants_workspace_active_idx on product_variants (workspace_id, is_active);
create unique index product_variants_workspace_sku_unique on product_variants (workspace_id, sku) where sku is not null;
```

## Carts

```sql
create index carts_workspace_contact_status_idx on carts (workspace_id, contact_id, status, updated_at desc);
create index carts_chat_status_idx on carts (chat_id, status);
create index carts_expires_idx on carts (status, expires_at) where expires_at is not null;
create index cart_items_cart_idx on cart_items (cart_id);
create index cart_items_product_idx on cart_items (workspace_id, product_id);
create unique index cart_items_unique_item_idx on cart_items (cart_id, product_id, variant_id);
```

Note: Postgres treats nulls as distinct. If `variant_id` can be null, add service-level duplicate guard or expression index with `coalesce`.

## Orders and Payments

```sql
create unique index orders_workspace_order_number_unique on orders (workspace_id, order_number);
create index orders_workspace_status_created_idx on orders (workspace_id, status, created_at desc);
create index orders_workspace_payment_status_created_idx on orders (workspace_id, payment_status, created_at desc);
create index orders_contact_created_idx on orders (workspace_id, contact_id, created_at desc);
create index orders_chat_id_idx on orders (chat_id);
create index order_items_order_idx on order_items (order_id);
create index order_items_product_idx on order_items (workspace_id, product_id);

create index payments_order_idx on payments (order_id);
create index payments_workspace_status_idx on payments (workspace_id, status, created_at desc);
create index payments_provider_order_idx on payments (provider, provider_order_id);
create index payments_provider_transaction_idx on payments (provider, provider_transaction_id);
create index payment_events_payment_idx on payment_events (payment_id);
create index payment_events_order_idx on payment_events (order_id);
create unique index payment_events_provider_event_unique on payment_events (provider, provider_event_id) where provider_event_id is not null;
```

## Complaints

```sql
create index complaints_workspace_status_created_idx on complaints (workspace_id, status, created_at desc);
create index complaints_chat_id_idx on complaints (chat_id);
create index complaints_contact_idx on complaints (workspace_id, contact_id, created_at desc);
create index complaints_text_trgm_idx on complaints using gin (text gin_trgm_ops);
```
