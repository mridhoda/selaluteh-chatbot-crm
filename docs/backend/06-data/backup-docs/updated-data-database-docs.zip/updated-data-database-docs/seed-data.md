# Seed Data

Seed data membantu development dan testing setelah Supabase schema dibuat.

## Goals

Minimal seed harus bisa menjalankan:

1. login admin
2. dashboard CRM
3. Telegram platform placeholder
4. default AI agent
5. sample contact/chat/message
6. sample product catalog
7. sample cart/order/payment sandbox flow

## Seed Order

```txt
1. workspaces
2. users
3. settings
4. platforms
5. agents
6. files optional
7. contacts
8. chats
9. messages
10. product_categories
11. products
12. product_variants
13. carts optional
14. orders optional
15. payments optional
```

## Minimal Dev Seed

Workspace:

```txt
name = Development Workspace
```

Owner:

```txt
name = Dev Owner
email = owner@example.com
role = owner
verified = true
plan = pro
```

Settings:

```json
{
  "primary_ai": "openai",
  "secondary_ai": "gemini",
  "commerce_config": {"currency":"IDR","telegram_marketplace_enabled":true},
  "payment_config": {"provider":"midtrans","mode":"sandbox"}
}
```

Telegram platform placeholder:

```txt
type = telegram
label = Development Telegram Bot
token = <redacted dev placeholder>
enabled = true
```

Default agent:

```txt
name = Default AI Agent
welcome_message = Halo! Ada yang bisa saya bantu?
behavior = You are a helpful customer service and shopping assistant.
```

Sample contact/chat/messages:

```txt
contact: Demo Telegram User, platform_type=telegram
chat: open, platform=telegram, agent=default
messages: user=Halo, ai=Halo! Ada yang bisa saya bantu?
```

## Product Seed

Categories:

```txt
Coffee
Non Coffee
Bundles
```

Products:

```txt
Salty Caramel | COF-SALTY-CARAMEL | Rp25.000 | featured
Aren Latte    | COF-AREN-LATTE    | Rp23.000 | featured
Chocolate     | NON-CHOCO         | Rp22.000
```

Variants optional:

```txt
Regular
Large
```

Example:

```txt
Salty Caramel Regular Rp25.000
Salty Caramel Large   Rp30.000
```

## Optional Demo Order

Only in development:

```txt
order_number = DEV-ORDER-0001
source = telegram_marketplace
status = pending_payment
payment_status = pending
subtotal = 25000
total_amount = 25000
```

Payment:

```txt
provider = midtrans
status = pending
amount = 25000
payment_url = https://example.test/payment-link
```

## Production Seed

Production should only seed:

```txt
required enum/type migrations
default settings during registration
```

Do not seed demo users, demo chats, demo orders, real tokens, or real payment keys.
