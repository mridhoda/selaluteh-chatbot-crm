# Migration Plan — MongoDB/Mongoose to Supabase/Postgres

Rencana migrasi dari MongoDB/Mongoose ke Supabase PostgreSQL, sambil menyiapkan foundation Telegram Marketplace MVP.

## Strategy

```txt
Phase 0: Safety fixes on current Mongo app
-> Phase 1: Supabase project setup
-> Phase 2: Repository layer
-> Phase 3: Schema migration
-> Phase 4: Route-by-route migration
-> Phase 5: Historical data import
-> Phase 6: Commerce module implementation
-> Phase 7: Payment sandbox
-> Phase 8: Cutover and verification
-> Phase 9: Remove Mongo dependency
```

Avoid big-bang rewrite.

## Phase 0 — Safety Fixes

Tasks:

1. Add auth and workspace filter to `orders` routes.
2. Add auth and workspace filter to `complaints` routes.
3. Mount `settings` route or remove frontend dependency.
4. Remove/protect diagnostic routes.
5. Add webhook idempotency based on Telegram update/message id.
6. Move AI side effects into service layer.
7. Confirm `.env` ignored.
8. Rotate exposed secrets if any.
9. Fix Vite env usage where legacy `REACT_APP_*` exists.

Definition of Done:

```txt
No public access to orders/complaints.
Telegram webhook still works.
AI reply still works.
No duplicate messages from repeated Telegram event.
```

## Phase 1 — Supabase Setup

Tasks:

1. Create Supabase project.
2. Enable `pgcrypto`, `citext`, `pg_trgm`.
3. Run SQL migrations.
4. Prepare local upload directory.
5. Add env:

```env
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
SUPABASE_ANON_KEY=
LOCAL_UPLOAD_ROOT=
PUBLIC_FILES_BASE_URL=
```

6. Enable RLS after schema creation.

## Phase 2 — Repository Layer

Add abstraction:

```txt
server/src/repositories/
  users.repository.js
  workspaces.repository.js
  settings.repository.js
  platforms.repository.js
  agents.repository.js
  contacts.repository.js
  chats.repository.js
  messages.repository.js
  files.repository.js
  orders.repository.js
  complaints.repository.js
  products.repository.js
  carts.repository.js
  payments.repository.js
  webhookEvents.repository.js
```

Initial implementation can wrap Mongoose. Later switch implementation to Supabase.

## Phase 3 — Schema Migration

Suggested SQL order:

```txt
00_extensions.sql
01_enums.sql
02_identity.sql
03_integrations.sql
04_files.sql
05_agents.sql
06_crm.sql
07_operations.sql
08_marketplace.sql
09_payments.sql
10_indexes.sql
11_triggers.sql
12_rls.sql
```

## Phase 4 — Route-by-route Migration

Recommended order:

1. `/auth`
2. `/profile`
3. `/platforms`
4. `/agents`
5. `/contacts`
6. `/chats`
7. `/webhook/telegram`
8. `/orders`
9. `/complaints`
10. `/analytics`
11. `/products`, `/carts`, `/checkout`, `/payments`

## Phase 5 — Historical Data Export

Export collections:

```txt
users
platforms
agents
contacts
chats
messages
orders
complaints
knowledge
otps
passwordresets
settings
```

Preserve `_id`, timestamps, workspaceId, userId, reference ids, attachment paths, platform message ids, and nested agent arrays.

## Phase 6 — ID Mapping

Mongo ObjectId must map to UUID.

```json
{"users":{"665...":"019..."},"chats":{"665...":"019..."}}
```

Optional staging table:

```txt
mongo_id_map(collection, mongo_id, postgres_id)
```

## Phase 7 — Data Load Order

```txt
1. workspaces
2. users
3. settings
4. platforms
5. files preliminary
6. agents
7. agent child tables
8. contacts
9. chats
10. files referenced by messages/orders
11. messages
12. orders
13. complaints
14. optional product catalog backfill
```

Existing orders are legacy AI form orders. Do not invent order_items if old form data is not structured enough.

## Phase 8 — Local File Metadata Migration

1. Scan attachment paths and agent files.
2. Verify files under `LOCAL_UPLOAD_ROOT`.
3. Optionally reorganize folder layout.
4. Insert `files` rows.
5. Patch `messages.attachment_file_id`, `orders.payment_proof_file_id`, `agent_database_files.file_id`.
6. Keep legacy JSON until frontend migrates.

## Phase 9 — Commerce Module

After CRM migration works:

1. Product catalog API.
2. Admin product UI.
3. Telegram product browsing.
4. Cart service.
5. Checkout service.
6. Order item creation.
7. Tests.

Do not build payment before cart/order deterministic.

## Phase 10 — Payment Sandbox

Tasks:

1. Add payment provider env keys.
2. Add provider client.
3. Create payment link service.
4. Add payment webhook route.
5. Verify signature.
6. Store payment_events.
7. Update payment/order status.
8. Notify Telegram user.

## Phase 11 — Cutover

1. Freeze writes briefly or maintenance mode.
2. Run final incremental migration.
3. Switch env to Supabase.
4. Verify login, dashboard, Telegram webhook, inbox, human takeover, AI reply, orders, complaints, products, cart, payment sandbox.
5. Monitor logs.

## Rollback

Rollback is possible only if MongoDB remains current, uploads backup is intact, and writes are frozen during cutover. Dual-write rollback needs reconciliation.
