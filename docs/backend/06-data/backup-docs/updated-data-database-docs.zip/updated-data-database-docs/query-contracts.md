# Query Contracts

Dokumen ini menjelaskan query behavior yang harus tetap sama setelah backend pindah ke Supabase/Postgres, plus query baru untuk Telegram-first Marketplace MVP.

## General Contract

Every authenticated route must:

```txt
1. attach current app user from JWT
2. determine workspace_id
3. scope every read/write by workspace_id
4. return 404/403 if resource does not belong to workspace
```

Public webhooks are exceptions, but they must derive `workspace_id` from verified platform/payment lookup.

## Auth

### Find User by Email

Used by:

```txt
POST /auth/login
POST /auth/forgot-password
```

Contract:

```txt
users.email is unique case-insensitive
password_hash is available until Supabase Auth is fully adopted
verified must be true for login
```

### Attach User from JWT

Current JWT contains app `users.id` and email. Repository must return:

```txt
id, workspace_id, email, role, status, plan
```

## Platform Lookup

### Telegram

Webhook lookup:

```txt
platforms.type = telegram
platforms.token = token param or configured token
platforms.enabled = true
```

Fallback compatibility:

```txt
latest telegram platform with non-empty token
```

### Meta WhatsApp

```txt
platforms.type = whatsapp
platforms.account_id = entry.id
```

### Instagram

```txt
platforms.type = instagram
platforms.account_id = recipient id or entry id
```

## Webhook Idempotency

Before processing:

```txt
find webhook_events by provider + external_event_id
```

If processed:

```txt
return 200 without duplicate side effects
```

Telegram preferred external id:

```txt
update_id
```

Message duplicate protection:

```txt
messages.platform_message_id unique-ish per chat/platform
```

## Agent Lookup

Primary:

```txt
agents.platform_id = platform.id
agents.is_active = true
```

Fallback:

```txt
oldest active agent in same workspace
```

## Contact Upsert

Webhook must find or create by:

```txt
workspace_id
platform_type
platform_account_id
```

On every inbound message, update `contacts.last_seen`.

## Chat Upsert

Webhook must find or create by:

```txt
workspace_id
platform_id
contact_id
```

If chat exists but `agent_id` empty, set it when agent is available.

If `status=resolved` and new inbound arrives, recommended behavior is set `status=open`.

## Inbox Query

`GET /chats` must support:

```txt
workspace filter
role filter for agent
unreadOnly
agentId
assignment
date range
tags
search by contact name or last message
sort by last_message_at desc
limit 200
```

Return:

```txt
chat, contact, agent, takeover_by user, last_message, platform_type
```

## Messages Query

`GET /chats/:id/messages` must:

```txt
validate workspace
set chats.unread = 0
return messages ordered by created_at asc
include reply_to message
limit 500
```

## Product Queries

Product list must support:

```txt
workspace_id scoped
is_active filter
category filter
search name/description/sku
sort sort_order asc, created_at desc
pagination
include thumbnail file
```

Product detail must:

```txt
validate workspace
include variants
include category
include thumbnail file
```

Product search for AI returns concise read-only fields only:

```txt
id, name, short_description, base_price, currency, variants, availability
```

## Cart Queries

Find active cart by:

```txt
workspace_id
contact_id
platform_type
status = active
```

Add item contract:

```txt
validate product active
validate variant active
resolve backend price
upsert cart_items by cart + product + variant
recalculate cart totals
```

Do not trust price/name from Telegram payload.

## Checkout Query

Create order from cart must run in transaction:

```txt
validate active cart
validate items
validate stock if stock_tracking true
generate order_number
create order status=pending_payment
copy cart_items to order_items
set cart.status=ordered
```

## Payment Queries

Create payment link:

```txt
validate order workspace
validate order.status=pending_payment or draft
validate amount > 0
create provider transaction
insert payments row
store payment_url
```

Process payment event:

```txt
insert payment_events first
verify signature
map provider status
update payment
update order
send Telegram notification if status changed
```

Must be idempotent.

## Telegram Commerce Callback Contract

Callback payload carries only IDs/action:

```txt
m:browse:p=1
m:product:<product_id>
m:add:<product_id>:<variant_id_or_none>:1
m:cart
m:checkout
m:orders
```

Backend validates all IDs against workspace.

## AI Query Contracts

AI may read:

```txt
agent config
knowledge
recent messages
product catalog summary
current cart summary
current contact order status
```

AI must not write directly to:

```txt
orders
payments
order_items
cart_items
```

AI returns proposed actions; backend validates them.
