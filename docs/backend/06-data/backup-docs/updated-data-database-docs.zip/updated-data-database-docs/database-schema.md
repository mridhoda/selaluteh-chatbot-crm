# Database Schema — Supabase/Postgres Target

Dokumen ini mendefinisikan schema target untuk migrasi dari MongoDB/Mongoose ke Supabase PostgreSQL dan perluasan menjadi **Telegram-first Marketplace MVP**.

## Target Architecture

```txt
Supabase/Postgres:
  structured data, CRM, chat, marketplace, payment metadata

Local server storage:
  image, video, audio, PDF, document, product image, payment proof

Backend:
  tetap wajib melakukan workspace validation walaupun RLS disiapkan
```

## Recommended Extensions

```sql
create extension if not exists "pgcrypto";
create extension if not exists "citext";
create extension if not exists "pg_trgm";
```

## Enums

```sql
create type user_role as enum ('owner', 'super', 'agent');
create type user_status as enum ('online', 'offline');
create type plan_type as enum ('free', 'pro', 'pro-banget');
create type platform_type as enum ('whatsapp', 'telegram', 'instagram', 'facebook', 'custom');
create type chat_status as enum ('open', 'resolved');
create type message_sender as enum ('user', 'ai', 'human', 'system');
create type knowledge_kind as enum ('url', 'pdf', 'text', 'file', 'qna');
create type order_status as enum ('draft','pending_payment','paid','processing','completed','cancelled','expired','failed','refunded');
create type payment_status as enum ('pending','paid','failed','expired','cancelled','refunded','partial_refund');
create type payment_provider as enum ('midtrans','xendit','manual','sandbox');
create type complaint_status as enum ('open','resolved','dismissed');
create type cart_status as enum ('active','checkout','ordered','abandoned','cancelled');
create type file_source as enum ('platform_inbound','crm_upload','agent_database','payment_proof','product_image','ai_generated','external_download','public_asset');
create type webhook_provider as enum ('telegram','whatsapp','instagram','facebook','midtrans','xendit','custom');
create type webhook_event_status as enum ('received','processing','processed','ignored','failed');
```

## Module Overview

| Module | Tables |
|---|---|
| Identity | `workspaces`, `users`, `otps`, `password_resets`, `settings` |
| Integration | `platforms`, `webhook_events` |
| AI Agent | `agents`, `agent_*` child tables |
| CRM | `contacts`, `chats`, `messages` |
| Files | `files` |
| Operations | `complaints` |
| Marketplace | `product_categories`, `products`, `product_variants`, `carts`, `cart_items`, `orders`, `order_items` |
| Payment | `payments`, `payment_events` |

## Identity

### workspaces

```txt
id uuid pk
name text
owner_user_id uuid nullable -> users.id
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

### users

```txt
id uuid pk
auth_user_id uuid nullable
workspace_id uuid -> workspaces.id
name text
email citext unique
password_hash text nullable
role user_role
verified boolean
status user_status
plan plan_type
plan_expiry timestamptz nullable
last_login_at timestamptz nullable
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

### settings

```txt
id uuid pk
workspace_id uuid unique
primary_ai text
secondary_ai text
ai_config jsonb
commerce_config jsonb
payment_config jsonb
created_at timestamptz
updated_at timestamptz
```

## Integration

### platforms

```txt
id uuid pk
workspace_id uuid
owner_user_id uuid nullable
type platform_type
label text
token text nullable
account_id text nullable
phone_number_id text nullable
app_id text nullable
app_secret text nullable
webhook_secret text nullable
enabled boolean
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

Token dan app secret idealnya dienkripsi atau dipindahkan ke secret manager.

### webhook_events

```txt
id uuid pk
workspace_id uuid nullable
platform_id uuid nullable
provider webhook_provider
external_event_id text nullable
event_type text nullable
payload_hash text nullable
payload jsonb
status webhook_event_status
error_message text nullable
received_at timestamptz
processed_at timestamptz nullable
created_at timestamptz
```

Digunakan untuk idempotency Telegram/Meta/payment webhook.

## AI Agent

`agents` menyimpan core config. Nested array lama dari Mongoose dinormalisasi ke child tables.

```txt
agents
agent_knowledge
agent_database_files
agent_followups
agent_complaint_fields
agent_outlets
agent_sales_forms
agent_sales_form_fields
agent_sales_form_products
agent_products
```

`agent_products` dan `agent_sales_form_products` dipertahankan sebagai compatibility bridge. Product catalog baru memakai `products` dan `product_variants`.

## CRM

### contacts

```txt
id uuid pk
workspace_id uuid
owner_user_id uuid nullable
name text nullable
platform_type platform_type
platform_account_id text
handle text nullable
last_seen timestamptz nullable
tags text[]
notes text nullable
metadata jsonb
created_at timestamptz
updated_at timestamptz
unique(workspace_id, platform_type, platform_account_id)
```

### chats

```txt
id uuid pk
workspace_id uuid
owner_user_id uuid nullable
agent_id uuid nullable
contact_id uuid
platform_id uuid nullable
platform_type platform_type
unread int
last_message_at timestamptz nullable
takeover_by uuid nullable
is_escalated boolean
status chat_status
state jsonb
created_at timestamptz
updated_at timestamptz
```

`takeover_by != null` berarti AI harus berhenti membalas.

### messages

```txt
id uuid pk
workspace_id uuid
chat_id uuid
sender message_sender
text text nullable
attachment_file_id uuid nullable
attachment jsonb nullable
reply_to uuid nullable
platform_message_id text nullable
provider_payload jsonb
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

## Files

```txt
id uuid pk
workspace_id uuid
storage_provider text default local
disk text default uploads
relative_path text
public_path text nullable
original_name text nullable
stored_name text
mime_type text nullable
size_bytes bigint nullable
source file_source
created_by uuid nullable
metadata jsonb
created_at timestamptz
unique(disk, relative_path)
```

## Marketplace

### product_categories

```txt
id uuid pk
workspace_id uuid
parent_id uuid nullable
name text
slug text
description text nullable
is_active boolean
sort_order int
metadata jsonb
created_at timestamptz
updated_at timestamptz
unique(workspace_id, slug)
```

### products

```txt
id uuid pk
workspace_id uuid
category_id uuid nullable
sku text nullable
slug text
name text
short_description text nullable
description text nullable
base_price numeric(14,2)
currency text default IDR
thumbnail_file_id uuid nullable
is_active boolean
is_featured boolean
stock_tracking boolean
stock_quantity int nullable
low_stock_threshold int nullable
sort_order int
metadata jsonb
created_at timestamptz
updated_at timestamptz
unique(workspace_id, slug)
unique(workspace_id, sku) where sku is not null
```

### product_variants

```txt
id uuid pk
workspace_id uuid
product_id uuid
sku text nullable
name text
option_values jsonb
price numeric(14,2) nullable
stock_quantity int nullable
is_active boolean
sort_order int
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

Jika `price` null, gunakan `products.base_price`.

### carts

```txt
id uuid pk
workspace_id uuid
contact_id uuid
chat_id uuid nullable
platform_id uuid nullable
platform_type platform_type
status cart_status
currency text
subtotal numeric(14,2)
discount_total numeric(14,2)
delivery_fee numeric(14,2)
tax_total numeric(14,2)
total_amount numeric(14,2)
metadata jsonb
expires_at timestamptz nullable
created_at timestamptz
updated_at timestamptz
```

### cart_items

```txt
id uuid pk
workspace_id uuid
cart_id uuid
product_id uuid
variant_id uuid nullable
quantity int
unit_price numeric(14,2)
total_price numeric(14,2)
product_snapshot jsonb
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

### orders

Orders mendukung legacy AI form order dan deterministic marketplace order.

```txt
id uuid pk
workspace_id uuid
order_number text
source text
chat_id uuid nullable
contact_id uuid nullable
agent_id uuid nullable
platform_id uuid nullable
cart_id uuid nullable
form_name text nullable
form_data jsonb
customer_name text nullable
customer_phone text nullable
customer_address jsonb
status order_status
payment_status payment_status
currency text
subtotal numeric(14,2)
discount_total numeric(14,2)
delivery_fee numeric(14,2)
tax_total numeric(14,2)
total_amount numeric(14,2)
notes text nullable
payment_proof_file_id uuid nullable
payment_proof_url text nullable
paid_at timestamptz nullable
completed_at timestamptz nullable
cancelled_at timestamptz nullable
metadata jsonb
created_at timestamptz
updated_at timestamptz
unique(workspace_id, order_number)
```

### order_items

```txt
id uuid pk
workspace_id uuid
order_id uuid
product_id uuid nullable
variant_id uuid nullable
product_name text
variant_name text nullable
sku text nullable
quantity int
unit_price numeric(14,2)
total_price numeric(14,2)
product_snapshot jsonb
metadata jsonb
created_at timestamptz
```

## Payment

### payments

```txt
id uuid pk
workspace_id uuid
order_id uuid
provider payment_provider
provider_order_id text nullable
provider_transaction_id text nullable
payment_url text nullable
status payment_status
amount numeric(14,2)
currency text
expiry_time timestamptz nullable
paid_at timestamptz nullable
raw_response jsonb
metadata jsonb
created_at timestamptz
updated_at timestamptz
```

### payment_events

```txt
id uuid pk
workspace_id uuid
payment_id uuid nullable
order_id uuid nullable
provider payment_provider
provider_event_id text nullable
event_type text nullable
transaction_status text nullable
fraud_status text nullable
signature_valid boolean nullable
payload jsonb
received_at timestamptz
processed_at timestamptz nullable
processing_error text nullable
created_at timestamptz
```

## Compatibility Notes

- Existing `orders.form_data` tetap dipertahankan untuk legacy `FILE_ORDER_JSON`.
- New marketplace order wajib membuat `order_items`.
- `orders.status` dan `orders.payment_status` dipisah karena fulfillment dan payment lifecycle berbeda.
- `messages.attachment` JSONB dipertahankan sementara selama migrasi, tetapi target jangka panjang memakai `attachment_file_id`.
