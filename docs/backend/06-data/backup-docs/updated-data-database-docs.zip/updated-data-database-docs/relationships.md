# Relationships

Dokumen ini menjelaskan relasi utama antara table target Supabase/Postgres untuk CRM + Telegram Marketplace MVP.

## Core Relationship Map

```txt
workspaces
  -> users
  -> settings
  -> platforms
  -> agents
  -> contacts
  -> chats
  -> messages
  -> files
  -> complaints
  -> product_categories
  -> products
  -> product_variants
  -> carts
  -> cart_items
  -> orders
  -> order_items
  -> payments
  -> payment_events
  -> webhook_events
```

## Primary Relations

| Parent | Child | Foreign Key | Behavior |
|---|---|---|---|
| `workspaces` | `users` | `users.workspace_id` | cascade |
| `workspaces` | `settings` | `settings.workspace_id` | cascade |
| `workspaces` | `platforms` | `platforms.workspace_id` | cascade |
| `workspaces` | `agents` | `agents.workspace_id` | cascade |
| `workspaces` | `contacts` | `contacts.workspace_id` | cascade |
| `workspaces` | `chats` | `chats.workspace_id` | cascade |
| `workspaces` | `messages` | `messages.workspace_id` | cascade |
| `workspaces` | `files` | `files.workspace_id` | cascade |
| `platforms` | `agents` | `agents.platform_id` | set null |
| `platforms` | `chats` | `chats.platform_id` | set null |
| `agents` | `chats` | `chats.agent_id` | set null |
| `contacts` | `chats` | `chats.contact_id` | restrict |
| `chats` | `messages` | `messages.chat_id` | cascade |
| `messages` | `messages` | `messages.reply_to` | set null |
| `files` | `messages` | `messages.attachment_file_id` | set null |
| `files` | `orders` | `orders.payment_proof_file_id` | set null |
| `files` | `products` | `products.thumbnail_file_id` | set null |
| `users` | `chats` | `chats.takeover_by` | set null |

## Agent Child Tables

| Parent | Child |
|---|---|
| `agents` | `agent_knowledge` |
| `agents` | `agent_database_files` |
| `agents` | `agent_followups` |
| `agents` | `agent_complaint_fields` |
| `agents` | `agent_outlets` |
| `agents` | `agent_sales_forms` |
| `agent_sales_forms` | `agent_sales_form_fields` |
| `agent_sales_forms` | `agent_sales_form_products` |
| `agents` | `agent_products` |

## Marketplace Relations

| Parent | Child | Foreign Key | Notes |
|---|---|---|---|
| `product_categories` | `product_categories` | `parent_id` | optional nested categories |
| `product_categories` | `products` | `products.category_id` | optional |
| `products` | `product_variants` | `product_variants.product_id` | cascade |
| `products` | `cart_items` | `cart_items.product_id` | restrict |
| `product_variants` | `cart_items` | `cart_items.variant_id` | restrict |
| `contacts` | `carts` | `carts.contact_id` | restrict |
| `chats` | `carts` | `carts.chat_id` | set null |
| `carts` | `cart_items` | `cart_items.cart_id` | cascade |
| `carts` | `orders` | `orders.cart_id` | set null |
| `orders` | `order_items` | `order_items.order_id` | cascade |
| `products` | `order_items` | `order_items.product_id` | set null |
| `product_variants` | `order_items` | `order_items.variant_id` | set null |

## Payment Relations

| Parent | Child | Foreign Key | Notes |
|---|---|---|---|
| `orders` | `payments` | `payments.order_id` | one order can have multiple attempts |
| `payments` | `payment_events` | `payment_events.payment_id` | set null for unmatched events |
| `orders` | `payment_events` | `payment_events.order_id` | audit lookup |

## Workspace Invariants

Application/repository layer wajib enforce:

```txt
chats.workspace_id = messages.workspace_id
chats.workspace_id = contacts.workspace_id
chats.workspace_id = platforms.workspace_id
chats.workspace_id = agents.workspace_id
carts.workspace_id = cart_items.workspace_id
orders.workspace_id = order_items.workspace_id
orders.workspace_id = payments.workspace_id
payments.workspace_id = payment_events.workspace_id
products.workspace_id = product_variants.workspace_id
```

Postgres tidak mudah enforce semua equality lintas table dengan FK sederhana. Service/repository layer wajib validasi.

## Delete Behavior Recommendations

| Scenario | Recommended Behavior |
|---|---|
| Delete workspace | cascade hanya untuk permanent deletion |
| Delete contact | prefer soft-delete/restrict |
| Delete platform | disable or set null on historical records |
| Delete agent | set null on historical chats/orders |
| Delete product | prefer deactivate, not hard delete |
| Delete product with order history | keep order item snapshot |
| Delete file | restrict or set null only intentionally |
| Delete payment | generally do not delete; keep audit |
