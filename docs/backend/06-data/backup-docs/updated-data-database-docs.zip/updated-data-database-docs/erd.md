# ERD — Updated CRM + Telegram Marketplace MVP

```mermaid
erDiagram
  WORKSPACES ||--o{ USERS : has
  WORKSPACES ||--|| SETTINGS : configures
  WORKSPACES ||--o{ PLATFORMS : owns
  WORKSPACES ||--o{ AGENTS : owns
  WORKSPACES ||--o{ CONTACTS : owns
  WORKSPACES ||--o{ CHATS : owns
  WORKSPACES ||--o{ MESSAGES : owns
  WORKSPACES ||--o{ FILES : owns
  WORKSPACES ||--o{ WEBHOOK_EVENTS : receives

  PLATFORMS ||--o{ AGENTS : assigned_to
  PLATFORMS ||--o{ CHATS : receives
  PLATFORMS ||--o{ CARTS : starts
  PLATFORMS ||--o{ ORDERS : originates

  AGENTS ||--o{ CHATS : handles
  AGENTS ||--o{ ORDERS : assists
  AGENTS ||--o{ COMPLAINTS : files

  CONTACTS ||--o{ CHATS : participates
  CONTACTS ||--o{ CARTS : owns
  CONTACTS ||--o{ ORDERS : customer
  CONTACTS ||--o{ COMPLAINTS : customer

  USERS ||--o{ CHATS : takeover_by

  CHATS ||--o{ MESSAGES : contains
  MESSAGES ||--o{ MESSAGES : reply_to
  FILES ||--o{ MESSAGES : attachment
  FILES ||--o{ PRODUCTS : thumbnail
  FILES ||--o{ ORDERS : payment_proof

  CHATS ||--o{ ORDERS : creates
  CHATS ||--o{ COMPLAINTS : creates
  CHATS ||--o{ CARTS : shopping_session

  AGENTS ||--o{ AGENT_KNOWLEDGE : has
  AGENTS ||--o{ AGENT_FOLLOWUPS : has
  AGENTS ||--o{ AGENT_DATABASE_FILES : has
  AGENTS ||--o{ AGENT_COMPLAINT_FIELDS : has
  AGENTS ||--o{ AGENT_OUTLETS : has
  AGENTS ||--o{ AGENT_PRODUCTS : legacy_products
  AGENTS ||--o{ AGENT_SALES_FORMS : has
  AGENT_SALES_FORMS ||--o{ AGENT_SALES_FORM_FIELDS : has
  AGENT_SALES_FORMS ||--o{ AGENT_SALES_FORM_PRODUCTS : legacy_form_products

  WORKSPACES ||--o{ PRODUCT_CATEGORIES : owns
  PRODUCT_CATEGORIES ||--o{ PRODUCT_CATEGORIES : parent_of
  PRODUCT_CATEGORIES ||--o{ PRODUCTS : groups
  PRODUCTS ||--o{ PRODUCT_VARIANTS : has
  PRODUCTS ||--o{ CART_ITEMS : selected
  PRODUCT_VARIANTS ||--o{ CART_ITEMS : selected_variant
  PRODUCTS ||--o{ ORDER_ITEMS : purchased
  PRODUCT_VARIANTS ||--o{ ORDER_ITEMS : purchased_variant

  CARTS ||--o{ CART_ITEMS : contains
  CARTS ||--o{ ORDERS : checked_out

  ORDERS ||--o{ ORDER_ITEMS : contains
  ORDERS ||--o{ PAYMENTS : paid_by
  PAYMENTS ||--o{ PAYMENT_EVENTS : receives
  ORDERS ||--o{ PAYMENT_EVENTS : audited_by
```

## Key Invariants

```txt
Every tenant-owned row must have workspace_id.
All workspace_id values across related rows must match.
```

Critical examples:

```txt
chats.workspace_id = messages.workspace_id
carts.workspace_id = cart_items.workspace_id
orders.workspace_id = order_items.workspace_id
orders.workspace_id = payments.workspace_id
payments.workspace_id = payment_events.workspace_id
```

## Commerce Lifecycle

```txt
Contact -> Chat -> Cart -> CartItems -> Order -> OrderItems -> Payment -> PaymentEvents
```

## CRM Lifecycle

```txt
Contact -> Chat -> Messages -> optional Human Takeover -> optional Order / Complaint
```

## AI Lifecycle

```txt
Agent -> Chat Handler -> Knowledge/Files -> AI Reply -> optional suggested action
```

AI should not directly mutate payment/order state without backend validation.
