# RLS Policies

Dokumen ini berisi desain Row Level Security untuk Supabase/Postgres.

## Principle

Setiap row tenant-owned hanya boleh diakses user yang berada di workspace sama:

```txt
row.workspace_id = current user's workspace_id
```

Jika backend memakai service role, RLS bisa bypass. Maka route backend tetap wajib validasi ownership.

## Helper Functions

```sql
create or replace function public.current_app_user_id()
returns uuid
language sql stable security definer
set search_path = public
as $$
  select id from public.users where auth_user_id = auth.uid() limit 1
$$;

create or replace function public.current_workspace_id()
returns uuid
language sql stable security definer
set search_path = public
as $$
  select workspace_id from public.users where auth_user_id = auth.uid() limit 1
$$;

create or replace function public.current_app_role()
returns user_role
language sql stable security definer
set search_path = public
as $$
  select role from public.users where auth_user_id = auth.uid() limit 1
$$;
```

## Generic Workspace Policy

For tenant tables:

```sql
alter table table_name enable row level security;

create policy "workspace select" on table_name
for select using (workspace_id = public.current_workspace_id());

create policy "workspace insert" on table_name
for insert with check (workspace_id = public.current_workspace_id());

create policy "workspace update" on table_name
for update using (workspace_id = public.current_workspace_id())
with check (workspace_id = public.current_workspace_id());

create policy "workspace delete" on table_name
for delete using (workspace_id = public.current_workspace_id());
```

Tenant tables include users, settings, platforms, agents, contacts, chats, messages, files, complaints, products, carts, orders, payments, and all child tables.

## Workspaces Policy

```sql
create policy "workspace members can select workspace"
on workspaces for select
using (id = public.current_workspace_id());
```

Owner/super can update workspace:

```sql
create policy "owner super can update workspace"
on workspaces for update
using (id = public.current_workspace_id() and public.current_app_role() in ('owner','super'))
with check (id = public.current_workspace_id() and public.current_app_role() in ('owner','super'));
```

## Human Agent Restriction

Owner/super can see workspace chats. Agent should only see assigned/taken-over chats.

```sql
create policy "chat role based select"
on chats for select
using (
  workspace_id = public.current_workspace_id()
  and (
    public.current_app_role() in ('owner','super')
    or takeover_by = public.current_app_user_id()
  )
);
```

Messages can mirror chat permission through exists query on `chats`.

## Product Policies

Recommended:

```txt
owner/super: manage product catalog
agent: read product catalog
```

Product update should require owner/super.

## Order and Payment Policies

Orders/payments are sensitive.

Recommended:

```txt
owner/super: full workspace access
agent: read only if linked chat is assigned/taken over
payment status update: backend service only after webhook/admin validation
```

Agents should not update payment status directly.

## Webhook Routes

Webhook routes are public externally. RLS does not authenticate Telegram/Meta/payment providers.

Webhook backend must:

1. verify platform/payment identity
2. find workspace
3. write using service role
4. store webhook/payment events
5. enforce idempotency

## Payment Webhook Security

Payment webhook must verify:

```txt
signature
order id
amount
provider transaction id
```

Invalid signature:

```txt
insert payment_event with signature_valid=false
never update payment/order
```

## File Access Policy

Current `/files` public static serving can stay during MVP. Future protected endpoint:

```txt
GET /media/:fileId
```

must authenticate user, check `files.workspace_id`, and stream local file.

Public product images can use `metadata.visibility=public`; private payment proof and chat attachments should be workspace-private.
