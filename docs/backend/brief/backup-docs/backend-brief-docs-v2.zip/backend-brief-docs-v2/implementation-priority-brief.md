# Implementation Priority Brief

## Recommended Priority Order

Do not start with payment first.

Recommended order:

```txt
1. Stabilize existing backend
2. Add webhook idempotency
3. Add service/repository boundaries
4. Add product catalog
5. Add cart
6. Add checkout
7. Add payment sandbox
8. Add Telegram commerce buttons
9. Add admin operations
10. Harden MVP
```

## Why This Order

### Payment depends on order

Payment link needs a pending order.

### Order depends on checkout

Order should be created from validated checkout.

### Checkout depends on cart

Checkout must validate cart items and totals.

### Cart depends on product

Cart item must reference active product/variant.

### Telegram commerce depends on product/cart

Inline buttons must call deterministic backend actions.

## Sprint Order

### Sprint 0 — Stabilization

- Secure orders.
- Secure complaints.
- Protect diagnostic routes.
- Keep Telegram webhook working.

### Sprint 1 — Webhook and Service Boundary

- Add webhook event idempotency.
- Extract chat/message/order/complaint services.
- Prepare AI action logging.

### Sprint 2 — Product Catalog

- Products.
- Categories.
- Variants.
- Product images.
- Product CRUD.

### Sprint 3 — Cart and Telegram Product Browsing

- Cart.
- Cart items.
- Telegram inline keyboard.
- Product list/detail.
- Add to cart.

### Sprint 4 — Checkout and Payment

- Checkout confirmation.
- Create order with order items.
- Payment link.
- Payment webhook.
- Payment event log.

### Sprint 5 — Admin Ops

- Product management.
- Order detail.
- Payment status.
- Customer chat context.

### Sprint 6 — Hardening

- Regression.
- Security checklist.
- Payment tests.
- Webhook tests.
- MVP demo.

## Current Best Next Step

Start with:

```txt
Sprint 0 — Stabilization
```

Because marketplace/payment should not be added before routes and workspace access are safe.
