# Quick Prompt for AI Coding Agent

Copy this into an AI coding agent when starting backend work.

```txt
You are working on SelaluTeh Chatbot CRM, an existing Express + React/Vite + MongoDB/Mongoose chatbot CRM that is being extended into a Telegram-first marketplace MVP.

Current system already has Telegram webhook, Meta webhook, AI agents, inbox/chats, contacts, human takeover, legacy orders/complaints, dashboard, and local file uploads.

Do not rebuild from scratch. Preserve existing CRM behavior.

Target MVP:
Telegram user can browse products, add to cart, checkout, receive payment link, complete sandbox payment, and receive paid notification. Admin can manage products, view orders, view payment status, and take over chats.

Important rules:
- Backend is source of truth for product/cart/order/payment.
- AI assists but cannot mark payment as paid or override order state.
- Payment webhook must be verified and idempotent.
- Every tenant-owned query must be workspace-scoped.
- Do not expose secrets.
- Do not break login, dashboard, inbox, Telegram webhook, AI reply, or human takeover.

Before payment work, prioritize:
1. Secure orders routes.
2. Secure complaints routes.
3. Protect/remove diagnostic routes.
4. Add webhook idempotency.
5. Add product catalog.
6. Add cart and checkout.

When you make changes, respond with:
- Summary
- Files changed
- Implementation notes
- Tests run/not run
- Risks
- Next recommended step
```
