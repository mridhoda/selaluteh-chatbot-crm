# Project Brief

## Project Name

SelaluTeh Chatbot CRM — Telegram Marketplace MVP

## One-Liner

An AI-powered chatbot CRM that is evolving into a Telegram-first conversational commerce system where customers can browse products, add items to cart, checkout, pay through a sandbox payment link, and receive order updates inside Telegram.

## Current Project Type

The current app is primarily:

```txt
Chatbot CRM multi-platform
```

It already supports:

- Telegram webhook.
- WhatsApp/Instagram webhook.
- AI agents.
- Inbox/chat history.
- Human takeover.
- Contacts.
- Legacy orders.
- Complaints.
- Dashboard.
- MongoDB/Mongoose runtime.

## New Product Direction

The new direction is:

```txt
Chat-first commerce backend
```

Starting with:

```txt
Telegram-first single-merchant marketplace MVP
```

## Core MVP Flow

```txt
Telegram user
→ /start
→ browse products
→ view product detail
→ add to cart
→ checkout
→ receive payment link
→ pay in sandbox
→ payment webhook updates order
→ user receives paid notification
→ admin sees order/payment status
```

## Important Principle

Do not rebuild from scratch.

Continue the existing CRM foundation and add marketplace primitives step by step.

## MVP Scope

In scope:

- Product catalog.
- Product variants.
- Cart.
- Checkout.
- Order items.
- Payment sandbox.
- Payment webhook.
- Telegram inline button commerce.
- Admin product/order operations.
- AI shopping assistant.
- Human takeover.

Out of scope:

- Multi-seller marketplace.
- Seller wallet.
- Seller payout.
- Commission engine.
- Logistics provider.
- Refund automation.
- Voucher engine.
- Public web storefront.
