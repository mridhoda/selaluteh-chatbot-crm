# Workspace Tenant Security

## Principle

Every tenant-owned row belongs to exactly one workspace.

```txt
row.workspace_id = current_user.workspace_id
```

## Tables That Must Be Workspace Scoped

```txt
users
platforms
agents
agent_* child tables
contacts
chats
messages
orders
order_items
complaints
products
product_categories
product_variants
product_images
carts
cart_items
checkouts
payments
payment_events
webhook_events
files
ai_actions
```

## Backend Rule

Never trust `workspace_id` from client body/query.

Correct:

```js
const workspaceId = req.user.workspace_id
await productsRepo.listForWorkspace(workspaceId)
```

Incorrect:

```js
await productsRepo.list(req.query.workspace_id)
```

## Repository Contract

Every repository method must either:

1. require `workspaceId` argument; or
2. be clearly marked internal/system-only.

Example:

```js
findOrderByIdForWorkspace(orderId, workspaceId)
listChatsForWorkspace(workspaceId, filters)
updateProductForWorkspace(productId, workspaceId, patch)
```

## Supabase RLS

RLS should be enabled for tenant tables. If backend uses service role, RLS may be bypassed, so backend still needs explicit checks.

## Cross-Workspace Test Cases

- User A cannot open chat from Workspace B.
- User A cannot update product from Workspace B.
- Telegram webhook cannot attach message to wrong workspace.
- Payment webhook cannot update order from a mismatched workspace/provider id.
- File metadata cannot be accessed outside workspace.
