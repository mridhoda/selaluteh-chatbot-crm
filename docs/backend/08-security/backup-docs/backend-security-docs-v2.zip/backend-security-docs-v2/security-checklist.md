# Security Checklist

## P0 — Must Fix Before Marketplace MVP

- [ ] `orders` API requires auth.
- [ ] `complaints` API requires auth.
- [ ] Every protected route uses workspace scoping.
- [ ] Diagnostic routes are removed/protected.
- [ ] Telegram webhook idempotency exists.
- [ ] Payment webhook signature verification exists.
- [ ] Payment status cannot be updated by AI directly.
- [ ] Supabase service role key is server-only.
- [ ] Platform tokens are never returned raw to frontend.
- [ ] File upload path traversal is prevented.
- [ ] File upload size/type limits exist.
- [ ] JWT secret is strong and not committed.

## P1 — Should Fix Before Public Beta

- [ ] Rate limiting for auth endpoints.
- [ ] Rate limiting for AI usage.
- [ ] Audit logs for payment/order/admin changes.
- [ ] Protected media endpoint for private files.
- [ ] CORS restricted to frontend domain.
- [ ] Helmet/security headers enabled.
- [ ] RLS policies reviewed and tested.
- [ ] Backup and restore test completed.
- [ ] Dependency audit workflow added.

## P2 — Hardening

- [ ] Encrypt platform tokens at rest.
- [ ] Add webhook event replay window checks.
- [ ] Add admin IP/device/session visibility.
- [ ] Add suspicious activity alerts.
- [ ] Add file virus scanning/quarantine.
- [ ] Add structured security logs.
- [ ] Add automated security regression tests.

## Smoke Test: Cross-Workspace

- [ ] Workspace A cannot read Workspace B chats.
- [ ] Workspace A cannot read Workspace B contacts.
- [ ] Workspace A cannot update Workspace B order.
- [ ] Agent cannot view unassigned chat unless allowed.

## Smoke Test: Payment

- [ ] Fake webhook without signature rejected.
- [ ] Duplicate webhook does not duplicate payment event effect.
- [ ] Pending order becomes paid only after verified settlement.
- [ ] Failed/expired payment does not mark order paid.

## Smoke Test: AI

- [ ] Prompt injection cannot mark payment paid.
- [ ] AI cannot bypass checkout confirmation.
- [ ] AI cannot access another workspace data.
- [ ] Human takeover disables AI reply.
