# User Personas

## Persona 1 — Business Owner

### Profile

- Pemilik bisnis/brand.
- Ingin jualan lewat chat tanpa membuat aplikasi mobile.
- Butuh melihat order dan chat customer secara cepat.

### Goals

- Meningkatkan conversion dari chat ke order.
- Mengurangi beban CS manual.
- Tetap bisa takeover percakapan penting.
- Punya dashboard untuk produk dan order.

### Pain Points

- Customer banyak tanya hal berulang.
- Order dari chat sering tercecer.
- Bukti bayar manual sulit diverifikasi.
- Data customer tersebar di banyak platform.

### Needs

- Unified inbox.
- AI assistant.
- Product catalog.
- Payment link.
- Order dashboard.

### Success Definition

Owner melihat lebih banyak chat berubah menjadi paid order dengan effort admin lebih sedikit.

---

## Persona 2 — Admin / Operations Staff

### Profile

- Mengelola produk, chat, dan order harian.
- Bukan developer.
- Butuh UI yang jelas dan minim risiko salah klik.

### Goals

- Menjawab chat customer.
- Takeover dari AI jika perlu.
- Melihat order masuk.
- Update status fulfillment.
- Mengelola produk aktif/tidak aktif.

### Pain Points

- Chat masuk banyak.
- Sulit tahu mana order sudah bayar.
- Produk/harga berubah tapi bot masih jawab data lama.
- Harus cek payment manual.

### Needs

- Inbox dengan status.
- Order list dengan payment status.
- Product CRUD simple.
- Notification saat payment success.

### Success Definition

Admin bisa menyelesaikan order tanpa keluar dari dashboard.

---

## Persona 3 — Human Agent / CS

### Profile

- CS yang menangani chat customer ketika AI tidak cukup.
- Role terbatas dibanding owner.

### Goals

- Melihat chat yang ditugaskan.
- Membalas customer.
- Memahami history chat dan order.
- Menyelesaikan masalah customer.

### Pain Points

- AI kadang salah paham.
- Customer komplain butuh respons manusia.
- CS butuh konteks order/payment.

### Needs

- Chat takeover.
- Chat history.
- Order context panel.
- Complaint note.

### Success Definition

CS bisa membantu customer tanpa akses berlebihan ke data workspace.

---

## Persona 4 — Telegram Customer

### Profile

- Customer yang membuka Telegram untuk bertanya/membeli.
- Tidak ingin install aplikasi baru.
- Bisa jadi sudah familiar dengan chat commerce.

### Goals

- Menemukan produk.
- Bertanya dulu sebelum membeli.
- Checkout mudah.
- Bayar lewat link aman.
- Mendapat update status order.

### Pain Points

- Website terlalu ribet.
- Chat manual lambat.
- Tidak tahu produk/harga terbaru.
- Takut pembayaran tidak tercatat.

### Needs

- Menu Telegram yang jelas.
- AI yang ramah dan membantu.
- Cart summary sebelum bayar.
- Payment link.
- Payment confirmation otomatis.

### Success Definition

Customer berhasil membeli tanpa perlu pindah ke website utama.

---

## Persona 5 — Developer / Maintainer

### Profile

- Engineer yang melanjutkan project lama.
- Perlu menjaga existing CRM tetap jalan sambil menambah commerce.

### Goals

- Menambah marketplace module tanpa merusak webhook/chat existing.
- Migrasi MongoDB ke Supabase/Postgres dengan aman.
- Menjaga security, data consistency, dan observability.

### Pain Points

- Existing code punya route yang belum aman.
- AI side effects bercampur dengan business logic.
- Order lama tidak normalized.
- Webhook duplicate bisa menyebabkan data double.

### Needs

- Clear schema.
- Repository layer.
- Migration docs.
- API contracts.
- Test strategy.

### Success Definition

Developer bisa implement fitur baru secara bertahap tanpa rebuild total.
