# Product Requirements

## Scope

Dokumen ini mendefinisikan kebutuhan produk untuk **Telegram-first Marketplace MVP** di atas existing Chatbot CRM.

## Functional Requirements

### Authentication & Workspace

- Owner dapat register workspace.
- Owner dapat login.
- User harus verified sebelum login.
- User memiliki role: `owner`, `super`, atau `agent`.
- Semua data operasional harus workspace-scoped.

### Platform Integration

- Owner dapat menambahkan platform Telegram.
- Backend dapat menyimpan token Telegram bot.
- Owner dapat menjalankan setWebhook dari dashboard/API.
- Webhook Telegram dapat menerima message dan callback query.
- Webhook harus idempotent agar duplicate update tidak menggandakan message/order.

### Chat & CRM

- Customer Telegram harus dibuat sebagai contact.
- Chat dibuat atau ditemukan berdasarkan workspace, platform, dan contact.
- Semua message masuk disimpan.
- AI dapat membalas jika human takeover tidak aktif.
- Human agent dapat takeover chat.
- Setelah takeover aktif, AI tidak boleh membalas chat tersebut.
- Admin dapat resolve chat.

### AI Assistant

- AI dapat menjawab FAQ dan pertanyaan produk.
- AI dapat membantu rekomendasi produk.
- AI boleh mengusulkan action seperti search product atau add to cart.
- Backend harus memvalidasi semua action sebelum dieksekusi.
- AI tidak boleh mengubah payment/order status.
- AI harus escalate ke human jika confidence rendah atau user marah.

### Product Catalog

- Admin dapat membuat produk.
- Admin dapat update produk.
- Admin dapat menonaktifkan produk.
- Produk memiliki nama, deskripsi, harga, status, dan optional image.
- Produk dapat memiliki variant.
- Produk dapat memiliki category.
- Produk yang inactive tidak boleh muncul di Telegram storefront.

### Cart

- Customer dapat menambahkan produk ke cart dari Telegram.
- Customer dapat melihat cart.
- Customer dapat mengubah quantity.
- Customer dapat menghapus item.
- Cart bersifat per customer/chat/workspace.
- Cart harus memiliki status seperti `active`, `checked_out`, `abandoned`, `cancelled`.

### Checkout

- Customer harus confirm cart sebelum order dibuat.
- Backend membuat checkout session.
- Backend membuat order dengan `order_items`.
- Checkout harus memiliki expiration policy.
- Backend harus mencegah duplicate checkout dari cart yang sama.

### Orders

- Order harus punya status lifecycle.
- Order harus memiliki item terstruktur.
- Order legacy dari AI form tetap didukung selama transisi.
- Admin dapat melihat dan update status order.
- Customer dapat cek status order dari Telegram.

### Payments

- MVP menggunakan payment link dari payment gateway sandbox.
- Backend membuat payment record untuk order.
- Backend menerima webhook payment.
- Webhook payment harus diverifikasi.
- Payment event harus disimpan.
- Order berubah menjadi paid hanya setelah webhook valid.
- Customer menerima notifikasi setelah payment success.

### Files & Media

- File binary tetap disimpan di local server storage.
- Database hanya menyimpan metadata file.
- Product images, payment proof, chat attachments, dan agent files memiliki folder terpisah.
- Jangan menyimpan absolute server path di database.

### Admin Dashboard

- Admin dapat melihat inbox.
- Admin dapat melihat messages.
- Admin dapat takeover chat.
- Admin dapat CRUD product.
- Admin dapat melihat orders.
- Admin dapat melihat payments.
- Admin dapat melihat complaints.

## Non-Functional Requirements

### Security

- Semua admin API harus auth required.
- Semua query harus workspace-scoped.
- Public webhook endpoint harus memverifikasi provider jika memungkinkan.
- Payment webhook wajib signature verification.
- Service role key tidak boleh tersedia di frontend.
- Secrets tidak boleh hardcoded.

### Reliability

- Webhook handler harus idempotent.
- Duplicate Telegram update tidak boleh duplicate message/order.
- Payment webhook retry tidak boleh double-update state.
- Local uploads harus persistent dan backup-ready.

### Performance

- Inbox harus sort by `last_message_at desc`.
- Message query harus limit dan pagination-ready.
- Product browsing Telegram harus cepat.
- Index harus mendukung lookup webhook, inbox, products, carts, orders, payments.

### Maintainability

- Route tidak boleh langsung berisi semua business logic.
- Domain operation ditempatkan di service/repository layer.
- AI side effects dipisahkan ke action validation layer.
- New marketplace module tidak boleh merusak existing CRM behavior.

## MVP Acceptance Criteria

MVP dianggap sukses jika:

- Telegram bot bisa menampilkan katalog produk.
- Customer bisa add to cart dari Telegram.
- Customer bisa checkout dari Telegram.
- Backend membuat order dan order items.
- Backend membuat payment link sandbox.
- Payment webhook sandbox mengubah order menjadi paid.
- Customer mendapat notifikasi paid.
- Admin bisa melihat order dan chat di dashboard.
- Human takeover tetap bekerja.
