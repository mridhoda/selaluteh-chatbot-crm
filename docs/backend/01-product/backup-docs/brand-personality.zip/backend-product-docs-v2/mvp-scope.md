# MVP Scope

## MVP Name

**Telegram-first Marketplace MVP**

## MVP Goal

Membuktikan bahwa existing Chatbot CRM dapat dipakai sebagai fondasi commerce berbasis Telegram, dari chat sampai order paid.

## MVP North Star

> Customer berhasil melakukan pembelian produk dari Telegram sampai payment success, sementara admin dapat memonitor chat dan order dari dashboard.

## Included in MVP

### Customer Telegram

- `/start` menu.
- Browse products.
- View product detail.
- Add to cart.
- View cart.
- Update quantity.
- Checkout confirmation.
- Receive payment link.
- Receive payment success notification.
- Check order status.
- Ask AI about products.
- Request human help.

### Admin Dashboard

- Login.
- View inbox.
- View chat messages.
- Human takeover.
- Product CRUD.
- View orders.
- Update order fulfillment status.
- View payment status.
- View customer contacts.

### Backend

- Workspace-scoped data.
- Product catalog.
- Cart.
- Checkout session.
- Orders and order items.
- Payment link creation.
- Payment webhook.
- Webhook idempotency.
- AI action guardrails.
- Local file metadata.

## Explicitly Excluded from MVP

- Multi-seller marketplace.
- Seller wallet.
- Commission engine.
- Seller payout.
- Logistics provider integration.
- Refund automation.
- Voucher/promo engine.
- Loyalty points.
- Customer mobile app.
- Public web storefront.
- Advanced inventory reservation.
- Complex warehouse management.
- Multi-currency.
- Native in-chat payment inside Telegram.

## MVP Release Boundary

MVP complete when this flow works end-to-end:

```txt
Telegram /start
↓
Browse product
↓
Add to cart
↓
Checkout
↓
Payment link sandbox
↓
Payment webhook success
↓
Order status paid
↓
Telegram notification
↓
Admin can view order
```

## Post-MVP Priorities

1. WhatsApp commerce flow.
2. Better AI product recommendation.
3. Product search with typo tolerance.
4. Promo/voucher.
5. Delivery fee calculation.
6. Refund workflow.
7. Multi-seller foundation.
8. Seller dashboard.
9. Analytics commerce dashboard.
