# Sprint Plan

Dokumen ini adalah rencana sprint backend untuk membangun Telegram Marketplace MVP di atas existing Chatbot CRM.

## Sprint 0 — Stabilize Existing CRM

### Goal

Menutup risiko besar sebelum fitur marketplace ditambahkan.

### Tasks

- [ ] Add auth middleware to orders routes.
- [ ] Add auth middleware to complaints routes.
- [ ] Add workspace scoping to orders query.
- [ ] Add workspace scoping to complaints query.
- [ ] Remove/protect public diagnostic user routes.
- [ ] Mount settings route or remove frontend dependency.
- [ ] Fix Vite env usage if any legacy `process.env.REACT_APP_*` remains.
- [ ] Add smoke test checklist.

### Acceptance Criteria

- Unauthenticated request cannot read/update orders.
- Unauthenticated request cannot read/update complaints.
- Existing login/dashboard/inbox works.
- Telegram webhook still replies.

## Sprint 1 — Webhook Idempotency & Service Boundaries

### Goal

Membuat webhook dan AI side effect lebih aman.

### Tasks

- [ ] Add `WebhookEvent` model/table.
- [ ] Store Telegram update/message id.
- [ ] Skip duplicate platform message.
- [ ] Extract order creation into order service.
- [ ] Extract complaint creation into complaint service.
- [ ] Extract chat/message insert into service layer.
- [ ] Add basic route/service tests.

### Acceptance Criteria

- Duplicate Telegram event does not create duplicate message.
- Order/complaint creation validates workspace.
- AI marker side effects go through service layer.

## Sprint 2 — Product Catalog

### Goal

Membangun catalog backend untuk marketplace MVP.

### Tasks

- [ ] Add product category model/table.
- [ ] Add product model/table.
- [ ] Add product variant model/table.
- [ ] Add product image metadata support.
- [ ] Add product CRUD API.
- [ ] Add admin product list/form or backend-ready API.
- [ ] Seed sample products.

### Acceptance Criteria

- Owner/super can create product.
- Active product can be listed by Telegram bot.
- Product has price, status, and optional variant.

## Sprint 3 — Cart & Telegram Commerce

### Goal

User Telegram bisa menambahkan produk ke cart.

### Tasks

- [ ] Add cart model/table.
- [ ] Add cart item model/table.
- [ ] Add cart service.
- [ ] Add Telegram inline keyboard helper.
- [ ] Add `/start` menu.
- [ ] Add product list callback.
- [ ] Add product detail callback.
- [ ] Add add-to-cart callback.
- [ ] Add view cart callback.

### Acceptance Criteria

- Telegram user can browse products.
- Telegram user can add item to cart.
- Cart persists across messages.
- Human takeover still disables AI reply but does not break manual admin handling.

## Sprint 4 — Checkout

### Goal

Cart bisa berubah menjadi pending order.

### Tasks

- [ ] Add checkout model/table.
- [ ] Add checkout service.
- [ ] Validate cart before checkout.
- [ ] Create order with order items.
- [ ] Add checkout confirmation message.
- [ ] Add cancellation/expiration rule.

### Acceptance Criteria

- User can confirm cart.
- Backend creates pending order with normalized order items.
- Cart cannot be checked out twice.

## Sprint 5 — Payment Sandbox

### Goal

Pending order bisa dibayar lewat payment gateway sandbox.

### Tasks

- [ ] Add payment provider abstraction.
- [ ] Add Midtrans/Xendit/manual sandbox adapter.
- [ ] Add payment row creation.
- [ ] Add payment link response.
- [ ] Add payment webhook endpoint.
- [ ] Verify webhook signature.
- [ ] Add payment event logging.
- [ ] Notify Telegram user after paid.

### Acceptance Criteria

- Payment link can be generated.
- Sandbox payment webhook changes payment status.
- Order becomes paid/processed according to business rule.
- Duplicate webhook is idempotent.

## Sprint 6 — Admin Ops & Hardening

### Goal

Admin bisa menjalankan MVP tanpa manual database access.

### Tasks

- [ ] Product management page/API complete.
- [ ] Order detail includes items/payment.
- [ ] Payment status visible.
- [ ] Logs and metrics added.
- [ ] Smoke test suite documented.
- [ ] Release checklist completed.

### Acceptance Criteria

- End-to-end demo works.
- Security checklist passes.
- Regression checklist passes.
