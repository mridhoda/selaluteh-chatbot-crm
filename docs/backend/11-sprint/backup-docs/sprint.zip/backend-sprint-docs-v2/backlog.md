# Backlog

Backlog ini mengelompokkan task berdasarkan domain.

## P0 — Must Have for MVP

### Security & Safety

- [ ] Secure orders API.
- [ ] Secure complaints API.
- [ ] Protect/remove diagnostic routes.
- [ ] Add workspace ownership validation.
- [ ] Add webhook idempotency.
- [ ] Verify payment webhook signature.
- [ ] Ensure service role key never reaches frontend.

### Existing CRM Preservation

- [ ] Login still works.
- [ ] Dashboard still works.
- [ ] Platforms page still works.
- [ ] Agents page still works.
- [ ] Inbox still works.
- [ ] Human takeover still works.
- [ ] AI reply still works.

### Product Catalog

- [ ] Product categories.
- [ ] Products.
- [ ] Product variants.
- [ ] Product images metadata.
- [ ] Admin product CRUD.
- [ ] Public/Telegram product listing.

### Cart & Checkout

- [ ] Cart.
- [ ] Cart items.
- [ ] Update cart quantity.
- [ ] Clear cart.
- [ ] Checkout confirmation.
- [ ] Create order with order items.

### Payment

- [ ] Payment provider abstraction.
- [ ] Sandbox payment link.
- [ ] Payment webhook.
- [ ] Payment event log.
- [ ] Order status update.
- [ ] Telegram paid notification.

### Telegram Commerce

- [ ] `/start` menu.
- [ ] Product list inline buttons.
- [ ] Product detail.
- [ ] Add to cart.
- [ ] View cart.
- [ ] Checkout.
- [ ] Payment link message.
- [ ] Order status command.

## P1 — Should Have

- [ ] Product search.
- [ ] AI product recommendation.
- [ ] Admin order filtering.
- [ ] Admin payment filtering.
- [ ] Manual payment fallback.
- [ ] Complaint link from order.
- [ ] Customer profile enrichment.
- [ ] Better file privacy endpoint.

## P2 — Later

- [ ] Multi-seller.
- [ ] Seller wallet.
- [ ] Payout.
- [ ] Commission.
- [ ] Voucher/promo.
- [ ] Logistics provider integration.
- [ ] Refund automation.
- [ ] Review/rating.
- [ ] Public web storefront.

## Not in MVP

- [ ] Full marketplace multi-tenant seller model.
- [ ] Native in-app wallet.
- [ ] Complex inventory reservation.
- [ ] Advanced recommendation engine.
- [ ] Automated dispute resolution.
