# Cart and Checkout Rules

## Purpose

Defines behavior for cart, cart items, checkout confirmation, and conversion into order.

## Cart Ownership

A cart belongs to:

```txt
workspace_id
contact_id
platform_type
platform_account_id or chat_id
```

For Telegram MVP, a customer should have one active cart per workspace/platform identity.

## Cart Status

Recommended statuses:

```txt
active
checked_out
abandoned
expired
cancelled
```

Rules:

- Only `active` carts can be modified.
- `checked_out` carts cannot be edited.
- `expired` carts require creating a new cart or reactivation with price refresh.

## Cart Item Rules

Cart item must include:

```txt
product_id
variant_id nullable
quantity
unit_price_snapshot
line_total_snapshot
```

Rules:

- quantity must be positive integer.
- maximum quantity per item should be configurable.
- adding the same product/variant should merge quantity unless product requires separate line item.
- backend recalculates price when adding/updating item.

## Price Refresh

Because product price can change, cart prices are snapshots, not final until checkout.

On checkout confirmation, backend must:

1. reload active products/variants
2. validate availability
3. recalculate totals
4. show final summary
5. require user confirmation

## Checkout Creation

Checkout is created from active cart after validation.

Checkout stores:

```txt
cart_id
contact_id
chat_id
summary
subtotal
discount_total
fee_total
grand_total
status
expires_at
```

## Checkout Status

Recommended statuses:

```txt
draft
awaiting_confirmation
confirmed
expired
cancelled
converted_to_order
```

## Explicit Confirmation Rule

Backend must not create final order/payment unless user explicitly confirms checkout.

Examples of explicit confirmation:

- Telegram button: `Confirm Checkout`
- User text mapped to confirmation: `ya`, `confirm`, `lanjut bayar`
- Admin manually creates order

AI-generated assumption is not enough.

## Cart Expiration

Recommended MVP default:

```txt
active cart expires after 24 hours of inactivity
checkout expires after 30-60 minutes if payment not started
```

## Cart Abandonment

Abandoned cart reminders may be added later.

MVP rule:

- No automatic reminder unless explicitly configured.
- Any reminder must respect platform messaging rules and user consent.

## Order Conversion

On confirmed checkout:

```txt
create order
create order_items from cart_items
mark checkout converted_to_order
mark cart checked_out
create payment row if payment gateway is selected
```

All steps must be transactional if possible.

## Error Cases

If product became unavailable during checkout:

```txt
remove unavailable item or block checkout
show updated cart summary
```

If price changed:

```txt
show updated price
require re-confirmation
```

If cart is empty:

```txt
checkout is rejected
```
