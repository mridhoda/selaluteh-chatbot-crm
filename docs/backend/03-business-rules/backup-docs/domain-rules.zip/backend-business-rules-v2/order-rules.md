# Order Rules

## Purpose

Defines order behavior for legacy CRM orders and new marketplace orders.

## Order Sources

Recommended enum:

```txt
ai_form
admin
telegram
whatsapp
instagram
api
```

Rules:

- `ai_form` preserves legacy `FILE_ORDER_JSON` behavior.
- `telegram` is the main source for marketplace MVP.
- `admin` is manual backend/dashboard creation.

## Order Structure

A marketplace order must have:

```txt
workspace_id
contact_id
chat_id nullable
source
status
payment_status
subtotal
discount_total
fee_total
grand_total
currency
```

And one or more `order_items`.

Legacy AI order may keep:

```txt
form_name
form_data
notes
```

## Order Item Snapshot

Every order item must preserve snapshot:

```txt
product_id nullable
variant_id nullable
product_name_snapshot
variant_name_snapshot
sku_snapshot
unit_price
quantity
line_total
```

Historical order must not change if product changes later.

## Order Status

Recommended lifecycle:

```txt
new
awaiting_payment
paid
processing
ready
completed
cancelled
expired
requires_review
```

For compatibility with legacy docs, map old statuses:

```txt
new -> new
processed -> processing
completed -> completed
cancelled -> cancelled
```

## Status Transition Rules

Allowed main path:

```txt
new -> awaiting_payment -> paid -> processing -> ready -> completed
```

Alternative paths:

```txt
new -> cancelled
awaiting_payment -> expired
awaiting_payment -> cancelled
paid -> requires_review
processing -> cancelled only by owner/super with reason
```

Rejected:

```txt
completed -> awaiting_payment
cancelled -> paid
expired -> paid without provider validation and admin review
```

## Payment Relationship

Marketplace order should have at least one payment row when payment is required.

Payment success updates:

```txt
payments.status = paid/settlement/success
orders.payment_status = paid
orders.status = paid or processing depending fulfillment policy
```

## Cancellation

Cancellation allowed if:

- order is not completed
- payment not paid, or refund/manual review is handled
- user has permission
- reason is provided for admin cancellation

If paid order is cancelled, payment/refund process must be tracked.

## Expiration

Orders awaiting payment may expire.

Recommended MVP:

```txt
payment link expiry from provider controls payment expiration
backend marks order expired when provider sends expire event or scheduled check confirms expiry
```

## Duplicate Order Prevention

Order creation must be idempotent for the same checkout.

Rules:

- one checkout should convert into one order only.
- repeated Telegram callback should return existing order/payment link.

## Legacy AI Order Rule

AI marker `FILE_ORDER_JSON` may continue creating simple orders, but marketplace order creation should use deterministic checkout service.

AI-generated order must still be workspace-scoped and validated.
