# Product Catalog Rules

## Purpose

Defines business behavior for products, categories, variants, pricing, visibility, and product media.

## Scope

MVP supports single-merchant product catalog per workspace.

## Product Ownership

Every product must belong to exactly one workspace.

```txt
products.workspace_id is required
```

Products cannot be shared across workspace.

## Product Status

Recommended product status:

```txt
draft
active
archived
out_of_stock
```

Rules:

- Only `active` products are visible to Telegram customers.
- `draft` products are visible only to admin.
- `archived` products cannot be added to cart.
- `out_of_stock` products may be shown but cannot be checked out unless backorder is explicitly enabled.

## Categories

Categories are optional for MVP but recommended.

Rules:

- Category belongs to workspace.
- Category can be hidden.
- Product can belong to zero or one category for MVP.
- Multi-category can be added later.

## Variants

Variants represent purchasable options such as size/flavor/package.

Rules:

- If product has variants, cart item must reference a variant.
- If product has no variants, cart item may reference product directly.
- Variant price can override product base price.
- Variant status must be active for checkout.

## Pricing

Backend must calculate prices.

Rejected behavior:

- AI sends final price as trusted value.
- Telegram callback includes trusted price.
- Frontend sends final total as trusted value.

Allowed behavior:

- Client sends `product_id`, `variant_id`, and `quantity`.
- Backend loads current price from DB.
- Backend computes subtotal, discount, fee, and total.

## Product Images

Product images are stored as local files with metadata in `files` and references through `product_images`.

Rules:

- Product image file must belong to same workspace.
- Product image public path must not expose absolute server path.
- Main image should be marked by `sort_order` or `is_primary`.

## Stock Rules

MVP can support simple stock:

```txt
stock_quantity integer nullable
track_inventory boolean default false
```

If `track_inventory = true`:

- quantity cannot go below zero.
- checkout must verify available stock.
- stock should be reduced only after order is paid or after order creation depending chosen reservation strategy.

Recommended MVP:

```txt
No hard stock reservation until payment success.
On payment success, reduce stock if track_inventory=true.
If stock insufficient at payment success, mark order requires_review.
```

## Product Search Rules

Search must be workspace-scoped.

Searchable fields:

```txt
name
description
sku
category name
variant name
```

For Telegram MVP, search can be simple SQL text search first.

## Deletion Rules

Products used in orders should not be hard-deleted.

Use:

```txt
archived
```

Reason: historical orders must preserve product references and price snapshot.

## Price Snapshot Rule

When cart becomes order, each `order_item` must store snapshot fields:

```txt
product_name_snapshot
variant_name_snapshot
unit_price_snapshot
quantity
line_total
```

This preserves historical order even if product is edited later.
